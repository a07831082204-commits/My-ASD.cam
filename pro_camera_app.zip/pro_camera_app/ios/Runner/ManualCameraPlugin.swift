import Flutter
import UIKit

/// نفس اسم القناة المستخدم في أندرويد بالضبط: "com.procamera/manual_camera"
/// حتى يبقى كود Dart موحداً بين المنصتين دون أي "if Platform.isIOS".
public class ManualCameraPlugin: NSObject, FlutterPlugin {
    private var manager: ManualCameraManager?
    private var registrar: FlutterPluginRegistrar?
    private var focusPeakingEventSink: FlutterEventSink?

    public static func register(with registrar: FlutterPluginRegistrar) {
        let channel = FlutterMethodChannel(
            name: "com.procamera/manual_camera",
            binaryMessenger: registrar.messenger()
        )
        let instance = ManualCameraPlugin()
        instance.registrar = registrar
        registrar.addMethodCallDelegate(instance, channel: channel)

        let focusPeakingChannel = FlutterEventChannel(
            name: "com.procamera/focus_peaking_frames",
            binaryMessenger: registrar.messenger()
        )
        focusPeakingChannel.setStreamHandler(FocusPeakingStreamHandler(plugin: instance))
    }

    public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        switch call.method {
        case "openCamera":
            openCamera(result: result)
        case "setManualExposure":
            let args = call.arguments as? [String: Any]
            let iso = (args?["iso"] as? NSNumber)?.floatValue ?? 100
            let exposureNanos = (args?["exposureNanos"] as? NSNumber)?.doubleValue ?? 8_000_000
            manager?.setManualExposure(
                iso: iso,
                exposureDurationSeconds: exposureNanos / 1_000_000_000.0
            )
            result(nil)
        case "setAutoExposure":
            manager?.setAutoExposure()
            result(nil)
        case "setFocusPeakingEnabled":
            let args = call.arguments as? [String: Any]
            let enabled = args?["enabled"] as? Bool ?? false
            manager?.focusPeakingEnabled = enabled
            result(nil)
        case "setFlashMode":
            let args = call.arguments as? [String: Any]
            let torch = args?["torch"] as? Bool ?? false
            manager?.setTorch(enabled: torch)
            result(nil)
        case "capturePhoto":
            let args = call.arguments as? [String: Any]
            let format = args?["format"] as? String ?? "jpeg"
            manager?.capturePhoto(format: format) { paths, error in
                if let error = error {
                    result(FlutterError(code: "CAPTURE_FAILED", message: error, details: nil))
                } else {
                    result(paths ?? [:])
                }
            }
        case "closeCamera":
            manager?.closeCamera()
            if let id = manager?.textureId, id >= 0 {
                registrar?.textures().unregisterTexture(id)
            }
            result(nil)
        default:
            result(FlutterMethodNotImplemented)
        }
    }

    private func openCamera(result: @escaping FlutterResult) {
        guard let registrar = registrar else {
            result(FlutterError(code: "NO_REGISTRAR", message: "لا يوجد registrar", details: nil))
            return
        }

        let newManager = ManualCameraManager()
        newManager.registry = registrar.textures()
        manager = newManager
        wireFocusPeakingCallback()

        let textureId = registrar.textures().register(newManager)
        newManager.textureId = textureId

        newManager.openCamera { outcome in
            switch outcome {
            case .success(var info):
                info["textureId"] = textureId
                result(info)
            case .failure(let error):
                result(FlutterError(
                    code: "OPEN_FAILED",
                    message: error.localizedDescription,
                    details: nil
                ))
            }
        }
    }

    /// يربط الـ callback الخاص بمدير الكاميرا الحالي بمُرسِل الأحداث
    /// (EventSink) إن كان الطرف Dart قد بدأ الاستماع للقناة فعلاً.
    /// نستدعي هذه الدالة في نقطتين: عند فتح كاميرا جديدة (لأن المدير
    /// يُعاد إنشاؤه في كل openCamera)، وعند بدء الاستماع للقناة
    /// (لأن المستخدم قد يُفعّل Focus Peaking بعد فتح الكاميرا بلحظات).
    fileprivate func wireFocusPeakingCallback() {
        guard let sink = focusPeakingEventSink else { return }
        manager?.onFocusPeakingFrame = { width, height, data in
            DispatchQueue.main.async {
                sink([
                    "width": width,
                    "height": height,
                    "bytes": FlutterStandardTypedData(bytes: data),
                ])
            }
        }
    }

    fileprivate func setFocusPeakingSink(_ sink: FlutterEventSink?) {
        focusPeakingEventSink = sink
        if sink == nil {
            manager?.onFocusPeakingFrame = nil
        } else {
            wireFocusPeakingCallback()
        }
    }
}

/// معالج قناة الأحداث (EventChannel) المسؤول عن بث كل إطار حواف
/// جاهز فور توفره من ManualCameraManager، إلى Dart كـ Map يحتوي
/// العرض والارتفاع وبيانات RGBA الخام.
private class FocusPeakingStreamHandler: NSObject, FlutterStreamHandler {
    private weak var plugin: ManualCameraPlugin?

    init(plugin: ManualCameraPlugin) {
        self.plugin = plugin
    }

    func onListen(withArguments arguments: Any?, eventSink events: @escaping FlutterEventSink) -> FlutterError? {
        plugin?.setFocusPeakingSink(events)
        return nil
    }

    func onCancel(withArguments arguments: Any?) -> FlutterError? {
        plugin?.setFocusPeakingSink(nil)
        return nil
    }
}
