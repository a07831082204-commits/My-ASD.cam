import Flutter
import UIKit

@main
@objc class AppDelegate: FlutterAppDelegate {
    override func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        GeneratedPluginRegistrant.register(with: self)

        // تسجيل الـ Plugin الأصلي يدوياً لأنه ليس Package منشوراً على pub.dev
        if let registrar = self.registrar(forPlugin: "ManualCameraPlugin") {
            ManualCameraPlugin.register(with: registrar)
        }

        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
}
