import AVFoundation
import Flutter
import UIKit

/// نظير iOS لـ ManualCameraManager على أندرويد.
/// يفتح AVCaptureSession مباشرة ويستخدم:
///   device.setExposureModeCustomWithDuration(duration:iso:completionHandler:)
/// وهي الدالة الوحيدة في AVFoundation التي تمنح تحكماً حقيقياً ومتزامناً
/// بسرعة الغالق (Duration) وISO معاً - تماماً مكافئ لـ SENSOR_EXPOSURE_TIME
/// و SENSOR_SENSITIVITY في Camera2 على أندرويد.
///
/// يطبّق هذا الكلاس بروتوكول FlutterTexture لتغذية المعاينة الحية مباشرة
/// كنص (Texture) لِـ Flutter، عبر تحويل كل CMSampleBuffer إلى CVPixelBuffer.
class ManualCameraManager: NSObject, FlutterTexture,
    AVCaptureVideoDataOutputSampleBufferDelegate,
    AVCapturePhotoCaptureDelegate {

    private let session = AVCaptureSession()
    private let sessionQueue = DispatchQueue(label: "com.procamera.session.queue")
    private let analysisQueue = DispatchQueue(label: "com.procamera.analysis.queue")
    private var device: AVCaptureDevice?
    private let videoOutput = AVCaptureVideoDataOutput()
    private let photoOutput = AVCapturePhotoOutput()

    private var latestPixelBuffer: CVPixelBuffer?
    private let pixelBufferLock = NSLock()

    var registry: FlutterTextureRegistry?
    var textureId: Int64 = -1

    // حالة الالتقاط الحالية: قد تتطلب نتيجة واحدة (JPEG فقط أو RAW فقط)
    // أو نتيجتين معاً (RAW+JPEG)، لأن AVCapturePhotoOutput يستدعي
    // photoOutput(_:didFinishProcessingPhoto:) مرة منفصلة لكل صيغة.
    private var pendingCaptureResults: [String: String] = [:]
    private var pendingCaptureExpectedCount = 1
    private var pendingCaptureCompletion: (([String: String]?, String?) -> Void)?

    // --- RAW Capture ---
    // نتحقق من توفر RAW فعلياً بعد بدء الجلسة، لأن
    // availableRawPhotoPixelFormatTypes لا يُملأ بشكل موثوق قبل ذلك.
    private(set) var supportsRaw: Bool = false

    // --- Focus Peaking ---
    var focusPeakingEnabled = false
    private var analysisFrameCounter = 0
    private let analysisFrameSkip = 2 // نعالج إطاراً واحداً كل 3 لتوفير الأداء
    private let analysisMaxDimension = 320 // نفس دقة التحليل المستخدمة في أندرويد
    /// يُستدعى من ManualCameraPlugin لبث كل قناع حواف جاهز إلى Dart
    var onFocusPeakingFrame: ((Int, Int, Data) -> Void)?

    // --- Flash / Torch ---
    // نقرأ توفر التورش فعلياً من الجهاز بدل افتراضه، لأن بعض أجهزة
    // آيباد وبعض إعدادات آيفون لا تملك وحدة فلاش خلفية.
    private(set) var hasTorch: Bool = false

    // النطاقات الفعلية المدعومة على جهاز المستخدم الحالي - تُقرأ من
    // activeFormat وليست ثابتة، لأنها تختلف بشدة بين أجهزة آيفون.
    private(set) var minISO: Float = 50
    private(set) var maxISO: Float = 1600
    private(set) var minExposureDurationSeconds: Double = 1.0 / 8000.0
    private(set) var maxExposureDurationSeconds: Double = 1.0

    func openCamera(completion: @escaping (Result<[String: Any], Error>) -> Void) {
        sessionQueue.async {
            do {
                try self.configureSession()
                DispatchQueue.main.async {
                    completion(.success([
                        "isoMin": self.minISO,
                        "isoMax": self.maxISO,
                        "shutterMinNanos": Int(self.minExposureDurationSeconds * 1_000_000_000),
                        "shutterMaxNanos": Int(self.maxExposureDurationSeconds * 1_000_000_000),
                        "supportsManualSensor": true,
                        "hasFlashUnit": self.hasTorch,
                        "supportsRaw": self.supportsRaw,
                    ]))
                }
            } catch {
                DispatchQueue.main.async { completion(.failure(error)) }
            }
        }
    }

    private func configureSession() throws {
        session.beginConfiguration()
        session.sessionPreset = .photo

        guard let camera = AVCaptureDevice.default(
            .builtInWideAngleCamera, for: .video, position: .back
        ) else {
            throw NSError(domain: "ManualCamera", code: 1,
                           userInfo: [NSLocalizedDescriptionKey: "لا توجد كاميرا خلفية"])
        }
        device = camera

        minISO = camera.activeFormat.minISO
        maxISO = camera.activeFormat.maxISO
        minExposureDurationSeconds = CMTimeGetSeconds(camera.activeFormat.minExposureDuration)
        maxExposureDurationSeconds = CMTimeGetSeconds(camera.activeFormat.maxExposureDuration)
        hasTorch = camera.hasTorch && camera.isTorchModeSupported(.on)

        let input = try AVCaptureDeviceInput(device: camera)
        if session.canAddInput(input) { session.addInput(input) }

        videoOutput.setSampleBufferDelegate(self, queue: sessionQueue)
        videoOutput.videoSettings =
            [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
        videoOutput.alwaysDiscardsLateVideoFrames = true
        if session.canAddOutput(videoOutput) { session.addOutput(videoOutput) }

        if session.canAddOutput(photoOutput) { session.addOutput(photoOutput) }

        session.commitConfiguration()
        session.startRunning()

        // availableRawPhotoPixelFormatTypes يُملأ فعلياً فقط بعد ربط
        // الإخراج بالجلسة وتشغيلها - قراءته قبل ذلك تُرجع دائماً فارغاً.
        supportsRaw = !photoOutput.availableRawPhotoPixelFormatTypes.isEmpty
    }

    /// التحكم اليدوي الحقيقي: يجب ضبط ISO وسرعة الغالق معاً في نفس النداء
    /// لأن AVFoundation تعاملهما كوحدة تعريض واحدة (custom exposure).
    func setManualExposure(iso: Float, exposureDurationSeconds: Double) {
        sessionQueue.async {
            guard let device = self.device else { return }
            let clampedIso = max(self.minISO, min(self.maxISO, iso))
            let clampedDuration = max(
                self.minExposureDurationSeconds,
                min(self.maxExposureDurationSeconds, exposureDurationSeconds)
            )
            do {
                try device.lockForConfiguration()
                device.setExposureModeCustomWithDuration(
                    CMTimeMakeWithSeconds(clampedDuration, preferredTimescale: 1_000_000_000),
                    iso: clampedIso,
                    completionHandler: nil
                )
                device.unlockForConfiguration()
            } catch {
                print("فشل ضبط التعريض اليدوي: \(error)")
            }
        }
    }

    func setAutoExposure() {
        sessionQueue.async {
            guard let device = self.device else { return }
            do {
                try device.lockForConfiguration()
                if device.isExposureModeSupported(.continuousAutoExposure) {
                    device.exposureMode = .continuousAutoExposure
                }
                device.unlockForConfiguration()
            } catch {
                print("فشل إعادة التعريض للوضع التلقائي: \(error)")
            }
        }
    }

    /// يُستدعى من Dart عبر MethodChannel لتفعيل/تعطيل التورش. يُتجاهل
    /// بصمت مع رسالة تحذير إن لم يكن الجهاز يملك وحدة فلاش أصلاً.
    func setTorch(enabled: Bool) {
        sessionQueue.async {
            guard let device = self.device, self.hasTorch else {
                print("هذا الجهاز لا يملك وحدة فلاش، تم تجاهل الطلب")
                return
            }
            do {
                try device.lockForConfiguration()
                device.torchMode = enabled ? .on : .off
                device.unlockForConfiguration()
            } catch {
                print("فشل ضبط التورش: \(error)")
            }
        }
    }

    /**
     * يلتقط صورة بالصيغة المطلوبة (jpeg / raw / rawPlusJpeg). عند طلب RAW
     * على جهاز لا يدعمه فعلياً ([supportsRaw] = false)، يُستبدل تلقائياً
     * بـ JPEG بدل فشل الالتقاط بالكامل، تماماً كما في نسخة أندرويد.
     *
     * [completion] يُستدعى مرة واحدة فقط بخريطة قد تحتوي "jpegPath"
     * و/أو "rawPath" حسب ما اكتمل فعلياً.
     */
    func capturePhoto(format: String, completion: @escaping ([String: String]?, String?) -> Void) {
        sessionQueue.async {
            let rawRequested = format == "raw" || format == "rawPlusJpeg"
            let wantsRaw = rawRequested && self.supportsRaw
            let wantsJpeg = format == "jpeg" || format == "rawPlusJpeg" || (rawRequested && !wantsRaw)

            if rawRequested && !wantsRaw {
                print("RAW غير مدعوم فعلياً على هذا الجهاز، تم الالتقاط بصيغة JPEG بدلاً منه")
            }

            let settings: AVCapturePhotoSettings
            if wantsRaw {
                // نختار أول صيغة RAW متاحة فعلياً على هذا الجهاز؛ الأجهزة
                // المختلفة تدعم صيغ Bayer مختلفة (12-bit عادة).
                let rawFormat = self.photoOutput.availableRawPhotoPixelFormatTypes.first!
                if wantsJpeg {
                    // RAW+JPEG في نداء التقاط واحد: AVCapturePhotoOutput يستدعي
                    // الـ delegate مرتين لنفس هذا الالتقاط - مرة لكل صيغة.
                    settings = AVCapturePhotoSettings(
                        rawPixelFormatType: rawFormat,
                        processedFormat: [AVVideoCodecKey: AVVideoCodecType.jpeg]
                    )
                } else {
                    settings = AVCapturePhotoSettings(rawPixelFormatType: rawFormat)
                }
            } else {
                settings = AVCapturePhotoSettings()
            }
            settings.flashMode = .off

            self.pendingCaptureResults = [:]
            self.pendingCaptureExpectedCount = (wantsJpeg ? 1 : 0) + (wantsRaw ? 1 : 0)
            self.pendingCaptureCompletion = completion

            self.photoOutput.capturePhoto(with: settings, delegate: self)
        }
    }

    func closeCamera() {
        sessionQueue.async {
            self.session.stopRunning()
        }
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

    func captureOutput(
        _ output: AVCaptureOutput,
        didOutput sampleBuffer: CMSampleBuffer,
        from connection: AVCaptureConnection
    ) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        pixelBufferLock.lock()
        latestPixelBuffer = pixelBuffer
        pixelBufferLock.unlock()

        if textureId >= 0 {
            registry?.textureFrameAvailable(textureId)
        }

        if focusPeakingEnabled {
            analysisFrameCounter += 1
            if analysisFrameCounter % (analysisFrameSkip + 1) == 0 {
                analysisQueue.async { [weak self] in
                    self?.processFocusPeakingFrame(pixelBuffer)
                }
            }
        }
    }

    /// يحسب قناع الحواف بنفس منطق Sobel المستخدم في FocusPeakingProcessor.kt
    /// على أندرويد، لكن هنا يُطبَّق على صورة BGRA بعد تصغيرها لدقة تحليل
    /// منخفضة (320px تقريباً) عبر أخذ عيّنات بخطوة (stride) بدل قراءة كل
    /// بكسل، لتفادي تجميد خيط المعالجة على الأجهزة الأضعف.
    private func processFocusPeakingFrame(_ pixelBuffer: CVPixelBuffer) {
        CVPixelBufferLockBaseAddress(pixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, .readOnly) }

        guard let baseAddress = CVPixelBufferGetBaseAddress(pixelBuffer) else { return }
        let srcWidth = CVPixelBufferGetWidth(pixelBuffer)
        let srcHeight = CVPixelBufferGetHeight(pixelBuffer)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(pixelBuffer)
        let buffer = baseAddress.assumingMemoryBound(to: UInt8.self)

        // معامل التصغير لجعل أطول ضلع قريباً من analysisMaxDimension
        let scale = max(1, srcWidth / analysisMaxDimension)
        let dstWidth = srcWidth / scale
        let dstHeight = srcHeight / scale
        guard dstWidth > 2, dstHeight > 2 else { return }

        // نحسب اللومينانس (السطوع) فقط من BGRA لكل بكسل معايَن، لأن
        // Focus Peaking يعتمد على تباين السطوع لا الألوان.
        func luma(_ x: Int, _ y: Int) -> Int {
            let px = min(x * scale, srcWidth - 1)
            let py = min(y * scale, srcHeight - 1)
            let offset = py * bytesPerRow + px * 4
            let b = Int(buffer[offset])
            let g = Int(buffer[offset + 1])
            let r = Int(buffer[offset + 2])
            return (r * 299 + g * 587 + b * 114) / 1000
        }

        var rgba = [UInt8](repeating: 0, count: dstWidth * dstHeight * 4)
        let threshold = 60

        for row in 1..<(dstHeight - 1) {
            for col in 1..<(dstWidth - 1) {
                let gx = -luma(col - 1, row - 1) + luma(col + 1, row - 1)
                    - 2 * luma(col - 1, row) + 2 * luma(col + 1, row)
                    - luma(col - 1, row + 1) + luma(col + 1, row + 1)

                let gy = -luma(col - 1, row - 1) - 2 * luma(col, row - 1) - luma(col + 1, row - 1)
                    + luma(col - 1, row + 1) + 2 * luma(col, row + 1) + luma(col + 1, row + 1)

                let magnitude = Int(Double(gx * gx + gy * gy).squareRoot())
                let idx = (row * dstWidth + col) * 4

                if magnitude > threshold {
                    // نفس اللون الأخضر النابض المستخدم في Flutter وأندرويد (0x34FF6A)
                    rgba[idx] = 0x34
                    rgba[idx + 1] = 0xFF
                    rgba[idx + 2] = 0x6A
                    rgba[idx + 3] = UInt8(min(255, magnitude))
                }
            }
        }

        let data = Data(rgba)
        onFocusPeakingFrame?(dstWidth, dstHeight, data)
    }

    // MARK: - FlutterTexture

    func copyPixelBuffer() -> Unmanaged<CVPixelBuffer>? {
        pixelBufferLock.lock()
        defer { pixelBufferLock.unlock() }
        guard let buffer = latestPixelBuffer else { return nil }
        return Unmanaged.passRetained(buffer)
    }

    // MARK: - AVCapturePhotoCaptureDelegate

    func photoOutput(
        _ output: AVCapturePhotoOutput,
        didFinishProcessingPhoto photo: AVCapturePhoto,
        error: Error?
    ) {
        if let error = error {
            pendingCaptureCompletion?(nil, error.localizedDescription)
            pendingCaptureCompletion = nil
            return
        }
        guard let data = photo.fileDataRepresentation() else {
            pendingCaptureCompletion?(nil, "تعذر استخراج بيانات الصورة")
            pendingCaptureCompletion = nil
            return
        }

        // AVCapturePhoto لصور RAW يُرجع fileDataRepresentation بصيغة DNG
        // جاهزة تلقائياً منذ iOS 10 - لا حاجة لأي تحويل يدوي، بعكس
        // أندرويد حيث يجب بناء DNG يدوياً عبر DngCreator.
        let isRaw = photo.isRawPhoto
        let ext = isRaw ? "dng" : "jpg"
        let key = isRaw ? "rawPath" : "jpegPath"
        let fileName = "IMG_\(Int(Date().timeIntervalSince1970 * 1000))_\(isRaw ? "raw" : "jpg").\(ext)"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(fileName)

        do {
            try data.write(to: url)
            pendingCaptureResults[key] = url.path
        } catch {
            pendingCaptureCompletion?(nil, error.localizedDescription)
            pendingCaptureCompletion = nil
            return
        }

        if pendingCaptureResults.count >= pendingCaptureExpectedCount {
            pendingCaptureCompletion?(pendingCaptureResults, nil)
            pendingCaptureCompletion = nil
        }
    }
}
