package com.example.pro_camera_app

import android.media.Image

/**
 * يحوّل إطار Y (luminance فقط من YUV_420_888) إلى قناع RGBA شفاف
 * يُبرز الحواف الحادة باللون الأخضر النابض (نفس AppColors.focusGreen
 * في Flutter: 0xFF34FF6A)، بنفس فكرة Focus Peaking في كاميرات
 * Sony/Panasonic الاحترافية: كلما كانت الحافة أوضح (تباين مفاجئ في
 * السطوع)، كان الجسم في تلك المنطقة أكثر وضوحاً في التركيز.
 *
 * ملاحظة أداء صادقة: هذا Sobel بسيط بحلقات Kotlin خالصة، وهو كافٍ
 * تماماً لدقة تحليل منخفضة (320x240) مع تخطي بعض الإطارات، لكنه
 * ليس الأمثل. للحصول على سلاسة أعلى (60fps) على الأجهزة الضعيفة
 * لاحقاً، الخطوة التالية هي نقل هذه الحلقة إلى RenderScript/NEON
 * عبر C++ (NDK) أو GPU Shader، دون تغيير أي شيء في واجهة الدالة.
 */
object FocusPeakingProcessor {
    // عتبة قوة الحافة لاعتبارها "حادة/مركّزة" - يمكن ضبطها تجريبياً
    private const val EDGE_THRESHOLD = 60

    // نفس اللون الأخضر المستخدم في واجهة Flutter (AppColors.focusGreen)
    private const val COLOR_R: Byte = 0x34
    private const val COLOR_G: Byte = 0xFF.toByte()
    private const val COLOR_B: Byte = 0x6A

    data class EdgeMask(val width: Int, val height: Int, val rgba: ByteArray)

    fun computeEdgeMask(image: Image): EdgeMask {
        val yPlane = image.planes[0]
        val buffer = yPlane.buffer
        val rowStride = yPlane.rowStride
        val pixelStride = yPlane.pixelStride
        val width = image.width
        val height = image.height

        val yBytes = ByteArray(buffer.remaining())
        buffer.get(yBytes)

        fun luma(x: Int, row: Int): Int {
            val index = row * rowStride + x * pixelStride
            return yBytes[index].toInt() and 0xFF
        }

        val rgba = ByteArray(width * height * 4)

        for (row in 1 until height - 1) {
            for (col in 1 until width - 1) {
                val gx = (-luma(col - 1, row - 1) + luma(col + 1, row - 1)
                        - 2 * luma(col - 1, row) + 2 * luma(col + 1, row)
                        - luma(col - 1, row + 1) + luma(col + 1, row + 1))

                val gy = (-luma(col - 1, row - 1) - 2 * luma(col, row - 1) - luma(col + 1, row - 1)
                        + luma(col - 1, row + 1) + 2 * luma(col, row + 1) + luma(col + 1, row + 1))

                val magnitude = kotlin.math.sqrt((gx * gx + gy * gy).toDouble()).toInt()
                val idx = (row * width + col) * 4

                if (magnitude > EDGE_THRESHOLD) {
                    rgba[idx] = COLOR_R
                    rgba[idx + 1] = COLOR_G
                    rgba[idx + 2] = COLOR_B
                    rgba[idx + 3] = magnitude.coerceAtMost(255).toByte()
                } else {
                    rgba[idx + 3] = 0
                }
            }
        }

        return EdgeMask(width, height, rgba)
    }
}
