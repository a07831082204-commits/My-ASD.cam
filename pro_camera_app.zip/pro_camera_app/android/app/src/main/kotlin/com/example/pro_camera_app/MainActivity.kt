package com.example.pro_camera_app

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine

// If your project uses a different package name than
// com.example.pro_camera_app, this file's package declaration above
// must match your actual package (same path under
// android/app/src/main/kotlin/...).
//
// This class extends io.flutter.embedding.android.FlutterActivity,
// which is Android Embedding v2 (correct). The deleted v1 class was
// io.flutter.app.FlutterActivity (no "embedding" in the path).
class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        flutterEngine.plugins.add(ManualCameraPlugin())
    }
}
