package com.example.pro_camera_app

import android.content.Context
import android.hardware.camera2.CameraAccessException
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.view.TextureRegistry

/**
 * القناة: "com.procamera/manual_camera"
 *
 * الدوال المكشوفة لـ Dart:
 *  - openCamera()                -> { "textureId": int, "isoMin": int, "isoMax": int,
 *                                       "shutterMinNanos": int, "shutterMaxNanos": int,
 *                                       "supportsManualSensor": bool, "hasFlashUnit": bool,
 *                                       "supportsRaw": bool }
 *  - setManualExposure(iso, exposureNanos)
 *  - setAutoExposure()
 *  - setFlashMode(torch)
 *  - capturePhoto(format, outputDir?) -> { "jpegPath"?: String, "rawPath"?: String }
 *    [format]: "jpeg" | "raw" | "rawPlusJpeg"
 *  - closeCamera()
 */
class ManualCameraPlugin : FlutterPlugin {
    private lateinit var channel: MethodChannel
    private lateinit var focusPeakingChannel: EventChannel
    private lateinit var textureRegistry: TextureRegistry
    private lateinit var context: Context
    private val mainHandler = Handler(Looper.getMainLooper())

    private var manager: ManualCameraManager? = null
    private var textureEntry: TextureRegistry.SurfaceTextureEntry? = null

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        context = binding.applicationContext
        textureRegistry = binding.textureRegistry
        channel = MethodChannel(binding.binaryMessenger, "com.procamera/manual_camera")
        channel.setMethodCallHandler { call, result -> handleCall(call, result) }

        focusPeakingChannel =
            EventChannel(binding.binaryMessenger, "com.procamera/focus_peaking_frames")
        focusPeakingChannel.setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
                manager?.onFocusPeakingFrame = { width, height, bytes ->
                    mainHandler.post {
                        events.success(
                            mapOf("width" to width, "height" to height, "bytes" to bytes)
                        )
                    }
                }
            }

            override fun onCancel(arguments: Any?) {
                manager?.onFocusPeakingFrame = null
            }
        })
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel.setMethodCallHandler(null)
        focusPeakingChannel.setStreamHandler(null)
        manager?.close()
        manager?.stopBackgroundThread()
    }

    private fun handleCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "openCamera" -> openCamera(result)
            "setManualExposure" -> {
                val iso = call.argument<Int>("iso") ?: 100
                val shutterNanos = (call.argument<Number>("exposureNanos") ?: 8_000_000L).toLong()
                manager?.setManualExposure(iso, shutterNanos)
                result.success(null)
            }
            "setAutoExposure" -> {
                manager?.setAutoExposure()
                result.success(null)
            }
            "setFocusPeakingEnabled" -> {
                val enabled = call.argument<Boolean>("enabled") ?: false
                manager?.focusPeakingEnabled = enabled
                result.success(null)
            }
            "setFlashMode" -> {
                val torch = call.argument<Boolean>("torch") ?: false
                manager?.setTorch(torch)
                result.success(null)
            }
            "capturePhoto" -> {
                val dirPath = call.argument<String>("outputDir")
                    ?: context.cacheDir.absolutePath
                val format = call.argument<String>("format") ?: "jpeg"
                manager?.capturePhoto(
                    java.io.File(dirPath),
                    format,
                    onCaptured = { paths ->
                        mainHandler.post { result.success(paths) }
                    },
                    onError = { message ->
                        mainHandler.post { result.error("CAPTURE_FAILED", message, null) }
                    },
                )
            }
            "closeCamera" -> {
                manager?.close()
                manager?.stopBackgroundThread()
                textureEntry?.release()
                result.success(null)
            }
            else -> result.notImplemented()
        }
    }

    private fun openCamera(result: MethodChannel.Result) {
        textureEntry = textureRegistry.createSurfaceTexture()
        val entry = textureEntry ?: return result.error("NO_TEXTURE", "تعذر إنشاء Texture", null)

        val newManager = ManualCameraManager(context, entry)
        manager = newManager
        newManager.startBackgroundThread()

        try {
            newManager.openCamera(
                onOpened = {
                    mainHandler.post {
                        result.success(
                            mapOf(
                                "textureId" to entry.id(),
                                "isoMin" to (newManager.isoRange?.lower ?: 50),
                                "isoMax" to (newManager.isoRange?.upper ?: 1600),
                                "shutterMinNanos" to (newManager.exposureTimeRangeNanos?.lower ?: 1_000_000L),
                                "shutterMaxNanos" to (newManager.exposureTimeRangeNanos?.upper ?: 1_000_000_000L),
                                "supportsManualSensor" to newManager.supportsManualSensor,
                                "hasFlashUnit" to newManager.hasFlashUnit,
                                "supportsRaw" to newManager.supportsRaw,
                            )
                        )
                    }
                },
                onError = { message ->
                    mainHandler.post { result.error("OPEN_FAILED", message, null) }
                },
            )
        } catch (e: CameraAccessException) {
            result.error("CAMERA_ACCESS_EXCEPTION", e.message, null)
        } catch (e: SecurityException) {
            result.error("PERMISSION_DENIED", "صلاحية الكاميرا غير ممنوحة", null)
        }
    }
}
