package com.example.pro_camera_app

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import io.flutter.view.TextureRegistry
import java.io.File
import java.io.FileOutputStream

/**
 * هذا الكلاس هو "الحقيقة الكاملة" للكاميرا على أندرويد.
 * يفتح الكاميرا مباشرة عبر Camera2 API (وليس عبر حزمة camera القياسية)
 * لأن التحكم اليدوي الحقيقي بـ ISO وسرعة الغالق يتطلب الوصول لمفاتيح
 * CaptureRequest التالية، وهي غير مكشوفة في حزمة camera:
 *   - CONTROL_AE_MODE = OFF   (لتعطيل التعريض التلقائي والسماح بالتحكم اليدوي)
 *   - SENSOR_SENSITIVITY      (= ISO الحقيقي)
 *   - SENSOR_EXPOSURE_TIME    (= سرعة الغالق الحقيقية بالنانو ثانية)
 *
 * ملاحظة صادقة: هذا يستبدل حزمة camera بالكامل لمسار المعاينة/الالتقاط.
 * لا يمكن تشغيل حزمة camera وهذا الكلاس على نفس الكاميرا في نفس اللحظة،
 * لأن كليهما يحاول فتح جلسة (CameraDevice/CaptureSession) حصرية.
 */
class ManualCameraManager(
    private val context: Context,
    private val textureEntry: TextureRegistry.SurfaceTextureEntry,
) {
    companion object {
        private const val TAG = "ManualCameraManager"
        private const val ANALYSIS_WIDTH = 320
        private const val ANALYSIS_HEIGHT = 240
        private const val ANALYSIS_FRAME_SKIP = 2 // نعالج إطاراً واحداً كل 3 لتوفير الأداء
    }

    private val cameraManager =
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var previewRequestBuilder: CaptureRequest.Builder? = null
    private var imageReader: ImageReader? = null
    private var cameraId: String = "0"

    private lateinit var backgroundThread: HandlerThread
    private lateinit var backgroundHandler: Handler

    // نطاقات الجهاز الفعلية - تُقرأ من CameraCharacteristics ولا تُفترض أبداً
    var isoRange: Range<Int>? = null
        private set
    var exposureTimeRangeNanos: Range<Long>? = null
        private set
    var supportsManualSensor: Boolean = false
        private set

    private var currentIso: Int = 100
    private var currentExposureNanos: Long = 1_000_000_000L / 125 // 1/125s افتراضياً
    private var manualModeEnabled = false

    // --- Focus Peaking ---
    // هذا الـ ImageReader الثانوي يستقبل نفس البث الحي لكن بدقة منخفضة
    // (320x240) مخصصة للتحليل فقط، منفصلة تماماً عن معاينة المستخدم
    // (previewSurface) وعن الالتقاط عالي الدقة (imageReader).
    private var analysisImageReader: ImageReader? = null
    private var analysisFrameCounter = 0

    var focusPeakingEnabled = false
    /** يُستدعى من ManualCameraPlugin لبث كل قناع حواف جاهز إلى Dart */
    var onFocusPeakingFrame: ((width: Int, height: Int, bytes: ByteArray) -> Unit)? = null

    // --- Flash / Torch ---
    // نقرأ توفر الفلاش فعلياً من CameraCharacteristics بدل افتراض
    // وجوده، لأن بعض الأجهزة اللوحية أو الكاميرات الأمامية لا تملك
    // وحدة فلاش إطلاقاً.
    var hasFlashUnit: Boolean = false
        private set
    private var torchEnabled = false

    // --- RAW Capture ---
    // نطاق DNG الحقيقي: يتطلب جهازاً يدعم REQUEST_AVAILABLE_CAPABILITIES_RAW
    // ويوفّر حجم إخراج فعلي بصيغة RAW_SENSOR. لا نفترض توفره أبداً.
    private var rawImageReader: ImageReader? = null
    var supportsRaw: Boolean = false
        private set

    // حالة مؤقتة لمطابقة صورة RAW الخام مع نتيجة الالتقاط (TotalCaptureResult)
    // الخاصة بها، لأن DngCreator يحتاج الاثنين معاً لبناء ملف DNG صحيح
    // يحتوي بيانات EXIF/معايرة الحساس الصحيحة. بما أن التطبيق يمنع
    // التقاط صورتين في آنٍ واحد، حقل واحد لكل منهما كافٍ تماماً.
    private var pendingRawImage: Image? = null
    private var pendingRawCaptureResult: TotalCaptureResult? = null
    private var pendingRawOutputFile: File? = null
    private var pendingRawOnDone: ((String) -> Unit)? = null
    private var pendingRawOnError: ((String) -> Unit)? = null

    fun startBackgroundThread() {
        backgroundThread = HandlerThread("ManualCameraBackground").also { it.start() }
        backgroundHandler = Handler(backgroundThread.looper)
    }

    fun stopBackgroundThread() {
        backgroundThread.quitSafely()
        try {
            backgroundThread.join()
        } catch (e: InterruptedException) {
            Log.e(TAG, "خطأ عند إيقاف الخيط الخلفي", e)
        }
    }

    /** يفتح أفضل كاميرا خلفية تدعم MANUAL_SENSOR إن وُجدت */
    @Throws(CameraAccessException::class)
    fun openCamera(onOpened: () -> Unit, onError: (String) -> Unit) {
        cameraId = pickBackCameraId()
        val characteristics = cameraManager.getCameraCharacteristics(cameraId)

        val capabilities =
            characteristics.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
        supportsManualSensor = capabilities?.contains(
            CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR
        ) == true

        isoRange = characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        exposureTimeRangeNanos =
            characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)

        if (!supportsManualSensor) {
            Log.w(TAG, "هذا الجهاز لا يدعم MANUAL_SENSOR - سيعمل التطبيق بوضع تلقائي فقط")
        }

        hasFlashUnit =
            characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true

        val map = characteristics.get(
            CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP
        )
        val jpegSizes = map?.getOutputSizes(ImageFormat.JPEG)
        val captureSize = jpegSizes?.maxByOrNull { it.width * it.height }
            ?: android.util.Size(1920, 1080)

        imageReader = ImageReader.newInstance(
            captureSize.width, captureSize.height, ImageFormat.JPEG, 2
        )

        // RAW حقيقي: يتطلب دعم REQUEST_AVAILABLE_CAPABILITIES_RAW *و*
        // وجود حجم إخراج فعلي بصيغة RAW_SENSOR - كلا الشرطين معاً،
        // لأن بعض الأجهزة تدّعي الدعم دون توفير حجم فعلي قابل للاستخدام.
        val rawSizes = map?.getOutputSizes(ImageFormat.RAW_SENSOR)
        val rawSize = rawSizes?.maxByOrNull { it.width * it.height }
        val deviceClaimsRawCapability = capabilities?.contains(
            CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW
        ) == true
        supportsRaw = deviceClaimsRawCapability && rawSize != null

        if (supportsRaw && rawSize != null) {
            rawImageReader = ImageReader.newInstance(
                rawSize.width, rawSize.height, ImageFormat.RAW_SENSOR, 2
            ).apply {
                // مستمع دائم: كل صورة RAW خام تصل تُخزَّن مؤقتاً بانتظار
                // مطابقتها مع نتيجة الالتقاط المقابلة (انظر tryWriteDngIfReady)
                setOnImageAvailableListener({ reader ->
                    val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                    pendingRawImage = image
                    tryWriteDngIfReady()
                }, backgroundHandler)
            }
        } else {
            Log.w(TAG, "هذا الجهاز لا يدعم RAW_SENSOR فعلياً - سيُستبدل بـ JPEG تلقائياً")
        }

        // ImageReader مخصص لتحليل Focus Peaking فقط - دقة منخفضة عمداً
        analysisImageReader = ImageReader.newInstance(
            ANALYSIS_WIDTH, ANALYSIS_HEIGHT, ImageFormat.YUV_420_888, 2
        ).apply {
            setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage()
                if (image == null) return@setOnImageAvailableListener

                if (!focusPeakingEnabled) {
                    image.close()
                    return@setOnImageAvailableListener
                }

                analysisFrameCounter++
                if (analysisFrameCounter % (ANALYSIS_FRAME_SKIP + 1) != 0) {
                    image.close()
                    return@setOnImageAvailableListener
                }

                try {
                    val mask = FocusPeakingProcessor.computeEdgeMask(image)
                    onFocusPeakingFrame?.invoke(mask.width, mask.height, mask.rgba)
                } catch (e: Exception) {
                    Log.e(TAG, "خطأ أثناء معالجة إطار Focus Peaking", e)
                } finally {
                    image.close()
                }
            }, backgroundHandler)
        }

        cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
            override fun onOpened(device: CameraDevice) {
                cameraDevice = device
                createCaptureSession(onOpened, onError)
            }

            override fun onDisconnected(device: CameraDevice) {
                device.close()
                cameraDevice = null
            }

            override fun onError(device: CameraDevice, error: Int) {
                device.close()
                cameraDevice = null
                onError("فشل فتح الكاميرا، كود الخطأ: $error")
            }
        }, backgroundHandler)
    }

    private fun pickBackCameraId(): String {
        for (id in cameraManager.cameraIdList) {
            val chars = cameraManager.getCameraCharacteristics(id)
            if (chars.get(CameraCharacteristics.LENS_FACING) ==
                CameraCharacteristics.LENS_FACING_BACK
            ) {
                return id
            }
        }
        return cameraManager.cameraIdList.first()
    }

    private fun createCaptureSession(onOpened: () -> Unit, onError: (String) -> Unit) {
        val device = cameraDevice ?: return

        val surfaceTexture = textureEntry.surfaceTexture()
        // حجم معاينة معقول ومتوافق مع أغلب الأجهزة؛ يمكن تحسينه لاحقاً
        // باختيار أفضل حجم من StreamConfigurationMap لنسبة الشاشة الفعلية.
        surfaceTexture.setDefaultBufferSize(1920, 1080)
        val previewSurface = Surface(surfaceTexture)

        val targets = mutableListOf(previewSurface)
        imageReader?.surface?.let { targets.add(it) }
        analysisImageReader?.surface?.let { targets.add(it) }
        rawImageReader?.surface?.let { targets.add(it) }

        device.createCaptureSession(
            targets,
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    captureSession = session
                    previewRequestBuilder = device.createCaptureRequest(
                        CameraDevice.TEMPLATE_PREVIEW
                    ).apply {
                        addTarget(previewSurface)
                        analysisImageReader?.surface?.let { addTarget(it) }
                        applyCurrentExposureSettings(this)
                    }
                    updateRepeatingRequest()
                    onOpened()
                }

                override fun onConfigureFailed(session: CameraCaptureSession) {
                    onError("فشل إعداد جلسة الالتقاط")
                }
            },
            backgroundHandler,
        )
    }

    /** يطبّق إما الوضع اليدوي (ISO + Shutter محددين) أو التلقائي بالكامل */
    private fun applyCurrentExposureSettings(builder: CaptureRequest.Builder) {
        if (manualModeEnabled && supportsManualSensor) {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            builder.set(CaptureRequest.SENSOR_SENSITIVITY, currentIso)
            builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, currentExposureNanos)
            // يجب أيضاً تعطيل التركيز التلقائي المستمر إن كان يعتمد AE داخلياً؛
            // نترك AF منفصلاً لأن المستخدم قد يريد AF مع AE يدوي.
        } else {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        }
        builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)

        // FLASH_MODE مستقل تماماً عن AE_MODE في Camera2: يعمل التورش
        // (إضاءة مستمرة) في كلا وضعي التعريض اليدوي والتلقائي.
        builder.set(
            CaptureRequest.FLASH_MODE,
            if (torchEnabled && hasFlashUnit) CaptureRequest.FLASH_MODE_TORCH
            else CaptureRequest.FLASH_MODE_OFF
        )
    }

    private fun updateRepeatingRequest() {
        val builder = previewRequestBuilder ?: return
        val session = captureSession ?: return
        applyCurrentExposureSettings(builder)
        session.setRepeatingRequest(builder.build(), null, backgroundHandler)
    }

    /**
     * يُستدعى من Dart عبر MethodChannel لتفعيل الوضع اليدوي بقيم فعلية.
     * [iso] و [exposureNanos] يجب أن يكونا ضمن [isoRange] و [exposureTimeRangeNanos]
     * وإلا سترفضهما الكاميرا أو تُقرّبهما تلقائياً حسب سلوك الجهاز.
     */
    fun setManualExposure(iso: Int, exposureNanos: Long) {
        if (!supportsManualSensor) {
            Log.w(TAG, "الجهاز لا يدعم MANUAL_SENSOR، تم تجاهل الطلب")
            return
        }
        manualModeEnabled = true
        currentIso = isoRange?.clamp(iso) ?: iso
        currentExposureNanos = exposureTimeRangeNanos?.clamp(exposureNanos) ?: exposureNanos
        updateRepeatingRequest()
    }

    fun setAutoExposure() {
        manualModeEnabled = false
        updateRepeatingRequest()
    }

    /**
     * يُستدعى من Dart عبر MethodChannel لتفعيل/تعطيل التورش (إضاءة
     * الفلاش المستمرة). يُتجاهل بصمت مع رسالة تحذير إن لم يكن
     * الجهاز يملك وحدة فلاش أصلاً، بدل التظاهر بأنه يعمل.
     */
    fun setTorch(enabled: Boolean) {
        if (!hasFlashUnit) {
            Log.w(TAG, "هذا الجهاز لا يملك وحدة فلاش، تم تجاهل الطلب")
            return
        }
        torchEnabled = enabled
        updateRepeatingRequest()
    }

    /**
     * يلتقط صورة بالصيغة المطلوبة (jpeg / raw / rawPlusJpeg). عند طلب RAW
     * على جهاز لا يدعمه فعلياً ([supportsRaw] = false)، يُستبدل تلقائياً
     * بـ JPEG بدل فشل الالتقاط بالكامل - قرار تجربة مستخدم مقصود، لكنه
     * يُبلَّغ في السجل بوضوح.
     *
     * [onCaptured] يُستدعى مرة واحدة فقط بخريطة قد تحتوي "jpegPath"
     * و/أو "rawPath" حسب ما اكتمل فعلياً.
     */
    fun capturePhoto(
        outputDir: File,
        format: String,
        onCaptured: (Map<String, String>) -> Unit,
        onError: (String) -> Unit,
    ) {
        val device = cameraDevice ?: return onError("الكاميرا غير مفتوحة")
        val session = captureSession ?: return onError("الجلسة غير جاهزة")

        val rawRequested = format == "raw" || format == "rawPlusJpeg"
        val wantsRaw = rawRequested && supportsRaw
        val wantsJpeg = format == "jpeg" || format == "rawPlusJpeg" || (rawRequested && !wantsRaw)

        if (rawRequested && !wantsRaw) {
            Log.w(TAG, "RAW غير مدعوم فعلياً على هذا الجهاز، تم الالتقاط بصيغة JPEG بدلاً منه")
        }

        val results = mutableMapOf<String, String>()
        var remaining = (if (wantsJpeg) 1 else 0) + (if (wantsRaw) 1 else 0)

        fun finishOne() {
            remaining--
            if (remaining <= 0) onCaptured(results)
        }

        if (wantsJpeg) {
            val reader = imageReader
            if (reader == null) {
                onError("ImageReader (JPEG) غير جاهز")
                return
            }
            reader.setOnImageAvailableListener({ r ->
                val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                val buffer = image.planes[0].buffer
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                image.close()

                val file = File(outputDir, "IMG_${System.currentTimeMillis()}.jpg")
                FileOutputStream(file).use { it.write(bytes) }
                results["jpegPath"] = file.absolutePath
                finishOne()
            }, backgroundHandler)
        }

        if (wantsRaw) {
            pendingRawImage = null
            pendingRawCaptureResult = null
            pendingRawOutputFile = File(outputDir, "IMG_${System.currentTimeMillis()}.dng")
            pendingRawOnDone = { path ->
                results["rawPath"] = path
                finishOne()
            }
            pendingRawOnError = { message -> onError(message) }
        }

        val captureBuilder = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
            if (wantsJpeg) imageReader?.surface?.let { addTarget(it) }
            if (wantsRaw) rawImageReader?.surface?.let { addTarget(it) }
            applyCurrentExposureSettings(this)
            set(CaptureRequest.JPEG_ORIENTATION, 90) // يُحسَّن لاحقاً حسب دوران الجهاز الفعلي
        }

        session.capture(
            captureBuilder.build(),
            object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    result: TotalCaptureResult,
                ) {
                    if (wantsRaw) {
                        pendingRawCaptureResult = result
                        tryWriteDngIfReady()
                    }
                }

                override fun onCaptureFailed(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    failure: CaptureFailure,
                ) {
                    if (wantsRaw) {
                        onError("فشل التقاط RAW، كود السبب: ${failure.reason}")
                    }
                }
            },
            backgroundHandler,
        )
    }

    /**
     * يكتب ملف DNG فعلياً فور توفر كل من صورة RAW الخام ونتيجة الالتقاط
     * المطابقة لها معاً (أيهما وصل أولاً ينتظر الآخر، والترتيب بينهما
     * غير مضمون في Camera2 API).
     */
    private fun tryWriteDngIfReady() {
        val image = pendingRawImage ?: return
        val result = pendingRawCaptureResult ?: return
        val file = pendingRawOutputFile

        if (file == null) {
            // لا يوجد التقاط RAW قيد الانتظار فعلياً (مثال: كان هذا مجرد
            // إطار قديم متبقٍ) - نتخلص منه فقط دون معالجة.
            image.close()
            pendingRawImage = null
            pendingRawCaptureResult = null
            return
        }

        try {
            val characteristics = cameraManager.getCameraCharacteristics(cameraId)
            DngCreator(characteristics, result).use { dngCreator ->
                FileOutputStream(file).use { fos ->
                    dngCreator.writeImage(fos, image)
                }
            }
            pendingRawOnDone?.invoke(file.absolutePath)
        } catch (e: Exception) {
            Log.e(TAG, "فشل كتابة ملف DNG", e)
            pendingRawOnError?.invoke("فشل حفظ RAW: ${e.message}")
        } finally {
            image.close()
            pendingRawImage = null
            pendingRawCaptureResult = null
            pendingRawOutputFile = null
            pendingRawOnDone = null
            pendingRawOnError = null
        }
    }

    fun close() {
        captureSession?.close()
        cameraDevice?.close()
        imageReader?.close()
        analysisImageReader?.close()
        rawImageReader?.close()
        captureSession = null
        cameraDevice = null
        imageReader = null
        analysisImageReader = null
        rawImageReader = null
        pendingRawImage = null
        pendingRawCaptureResult = null
        pendingRawOutputFile = null
    }
}

/** دالة مساعدة صغيرة لتقريب قيمة ضمن مدى مدعوم فعلياً من الجهاز */
private fun <T : Comparable<T>> android.util.Range<T>.clamp(value: T): T {
    return when {
        value < lower -> lower
        value > upper -> upper
        else -> value
    }
}

private typealias Range<T> = android.util.Range<T>
