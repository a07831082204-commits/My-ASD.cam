# شرح AndroidManifest.xml

هذا الملف يشرح محتوى `AndroidManifest.xml` سطراً بسطر. الملف نفسه
(`.xml`) أصبح خالياً تماماً من أي حرف عربي أو تعليق (0 بايت غير
ASCII، تم التحقق برمجياً) بعد مشكلة استمرار ظهور خطأ
"deleted Android v1 embedding" رغم صحة المحتوى ظاهرياً - الاشتباه
كان أن تعليقات عربية (RTL) مطعَّمة داخل كود XML (LTR) قد تحمل محارف
اتجاه خفية (Bidi control characters) غير مرئية تُفسد فحصاً نصياً
حرفياً تقوم به منصة FlutLab، رغم أنها تُعرض بصرياً بشكل طبيعي تماماً
في المحرر.

## الأذونات
- `CAMERA`: أساسي لعمل التطبيق بالكامل.
- `WRITE_EXTERNAL_STORAGE` بحد أقصى API 28: مطلوب فقط لأندرويد 9
  وأقل؛ الإصدارات الأحدث تستخدم MediaStore عبر حزمة `gal` دون
  الحاجة لهذا الإذن إطلاقاً.
- `uses-feature camera` و`camera.autofocus` بقيمة `required="false"`:
  يعلن أن الجهاز يملك كاميرا، لكن لا يمنع التثبيت على أجهزة نادرة
  بلا كاميرا خلفية.

## وسم application
- `android:name="${applicationName}"`: قيمة تُستبدَل تلقائياً من
  Gradle، لا تُغيَّر يدوياً.
- `android:icon`: أيقونة التطبيق القياسية.

## وسم activity
- `android:name=".MainActivity"`: النقطة `.` تعني "نفس حزمة التطبيق
  تلقائياً"، أياً كانت حزمتك الفعلية - لا حاجة لتعديلها حتى لو كانت
  حزمتك مختلفة عن `com.example.pro_camera_app`.
- `android:theme="@style/LaunchTheme"`: يتطلب وجود `styles.xml`
  يعرّف هذا الثيم (مُرفَق في مشروعك بالفعل).
- `meta-data io.flutter.embedding.android.NormalTheme`: الثيم الذي
  يُستبدَل به `LaunchTheme` فور جاهزية Flutter بالكامل، وفق آلية
  `FlutterActivity` القياسية نفسها.
- `intent-filter` بـ `MAIN`/`LAUNCHER`: يجعل هذا النشاط هو الشاشة
  التي تُفتح عند الضغط على أيقونة التطبيق.

## السطر الحاسم لحل خطأ "deleted Android v1 embedding"
```xml
<meta-data
    android:name="flutterEmbedding"
    android:value="2"/>
```
هذا يُصرِّح صراحة أن المشروع يستخدم Flutter Android Embedding v2.
بدونه، بعض إصدارات أدوات البناء (خصوصاً القوالب القديمة أحياناً
تعتمدها منصات مثل FlutLab) تفترض v1 افتراضياً وترفض البناء فوراً.

## وسم queries
مطلوب على أندرويد 11 (API 30) فما فوق حتى يستطيع التطبيق "رؤية"
تطبيقات المعرض المثبتة والتفاعل معها بشكل صحيح عبر حزمة `gal`؛
بدونه قد تفشل بعض عمليات الحفظ بصمت على هذه الإصدارات تحديداً.

## إن استمر الخطأ رغم هذا الملف النظيف
هذا يعني أن السبب على الأرجح ليس في `AndroidManifest.xml` نفسه، بل
في أحد هذين:
1. **`MainActivity.kt` نفسه** - افتحه في FlutLab وتأكد أن أول سطر
   استيراد فيه هو بالضبط:
   ```kotlin
   import io.flutter.embedding.android.FlutterActivity
   ```
   وليس `io.flutter.app.FlutterActivity` (بدون كلمة embedding في
   المسار - هذه هي الفئة القديمة المحذوفة فعلياً).
2. **نسخة Flutter SDK التي تستخدمها FlutLab نفسها قديمة جداً**
   (أقدم من أواخر 2023 تقريباً) بحيث لا تدعم v2 embedding بشكل صحيح
   حتى مع كل الإعدادات الصحيحة - في هذه الحالة الحل ليس في الكود
   إطلاقاً، بل يتطلب التواصل مع دعم FlutLab نفسه لتحديث نسخة Flutter
   المستخدمة في البناء.
