import 'dart:io';
import 'package:gal/gal.dart';

/// نتيجة محاولة حفظ ملفات التقاط واحد (JPEG و/أو RAW) في المعرض.
/// [warning] يحمل رسالة غير حرجة عند فشل جزء من العملية (مثال: نجح
/// حفظ JPEG لكن فشل حفظ RAW)، بدل رمي استثناء يوقف التطبيق بالكامل
/// من أجل خطأ في نصف العملية فقط.
class GallerySaveResult {
  final bool savedJpegToGallery;
  final bool savedRawToGallery;
  final String? warning;

  GallerySaveResult({
    required this.savedJpegToGallery,
    required this.savedRawToGallery,
    this.warning,
  });
}

/// يُستدعى عندما يرفض المستخدم إذن الوصول للمعرض صراحة. حالة مختلفة
/// عمداً عن [GallerySaveResult.warning] لأنها تعني فشل العملية بأكملها
/// وليس جزءاً منها فقط.
class GalleryPermissionDeniedException implements Exception {
  @override
  String toString() =>
      'تم رفض إذن الوصول لمعرض الصور. لن تُحفظ الصور بشكل دائم حتى '
      'يُمنح الإذن من إعدادات النظام.';
}

/// طبقة مسؤولة حصراً عن نقل الملفات من التخزين المؤقت (حيث يكتبها
/// الجسر الأصلي في native_camera_bridge.dart) إلى معرض الصور الدائم،
/// باستخدام حزمة gal التي تتعامل مع MediaStore على أندرويد وPhotos
/// Framework على iOS بشكل صحيح عبر القنوات الرسمية لكل نظام.
///
/// ملاحظة صادقة عن الأذونات: هذه الخدمة تستخدم Gal.hasAccess/
/// requestAccess بدل حزمة permission_handler لطلب إذن المعرض تحديداً،
/// لأن gal يطلب بالضبط إذن "الإضافة فقط" (Add-only) على iOS 14+
/// و MediaStore الصحيح على أندرويد حسب إصدار API - وهو أدق وأقل
/// تطفلاً من طلب إذن "قراءة كل الصور" الذي كان main.dart يطلبه
/// سابقاً بشكل عام عبر permission_handler.
class GalleryService {
  static const String albumName = 'Pro Camera';

  Future<bool> _ensureAccess() async {
    final hasAccess = await Gal.hasAccess(toAlbum: true);
    if (hasAccess) return true;
    return Gal.requestAccess(toAlbum: true);
  }

  /// ينقل [jpegPath] و/أو [rawPath] (أيهما غير null) إلى ألبوم مخصص
  /// باسم "Pro Camera" في معرض الصور. عند رفض الإذن، يُرمى
  /// [GalleryPermissionDeniedException] فوراً دون أي محاولة حفظ.
  Future<GallerySaveResult> saveCapturedFiles({
    String? jpegPath,
    String? rawPath,
  }) async {
    final granted = await _ensureAccess();
    if (!granted) {
      throw GalleryPermissionDeniedException();
    }

    var savedJpeg = false;
    var savedRaw = false;
    final warnings = <String>[];

    if (jpegPath != null) {
      try {
        await Gal.putImage(jpegPath, album: albumName);
        savedJpeg = true;
        // نُبقي النسخة المؤقتة عمداً بعد نجاح الحفظ: الواجهة تعرضها
        // كصورة مصغّرة عبر FileImage، وحجم JPEG صغير (بضعة ميجابايتات
        // كحد أقصى) بحيث لا يستحق تعقيد الكود لحذفه وإعادة تحميل بايتات
        // الصورة في الذاكرة فقط لعرض المصغّرة.
      } on GalException catch (e) {
        warnings.add('فشل حفظ JPEG في المعرض: ${e.type.message}');
      }
    }

    if (rawPath != null) {
      try {
        await Gal.putImage(rawPath, album: albumName);
        savedRaw = true;
        // على عكس JPEG: نحذف نسخة RAW المؤقتة فوراً بعد نجاح الحفظ،
        // لأنها كبيرة جداً (قد تتجاوز 30 ميجابايت) ولا تُعرض مباشرة في
        // أي مكان بالواجهة (فقط شارة "RAW" الصغيرة) - إبقاؤها في
        // التخزين المؤقت يراكم مساحة ضخمة بلا أي فائدة فعلية.
        await _deleteTempFile(rawPath);
      } on GalException catch (e) {
        // بعض تطبيقات المعرض أو إصدارات أندرويد القديمة قد لا تتعرف
        // على صيغة DNG (notSupportedFormat). في هذه الحالة نُبقي
        // الملف المؤقت كما هو بدل حذفه، حتى لا يفقد المستخدم صورته
        // الخام بسبب عدم توافق تطبيق المعرض فقط.
        warnings.add(
          'فشل حفظ RAW في المعرض: ${e.type.message} '
          'تم الاحتفاظ بالنسخة المؤقتة لتفادي فقدانها.',
        );
      }
    }

    return GallerySaveResult(
      savedJpegToGallery: savedJpeg,
      savedRawToGallery: savedRaw,
      warning: warnings.isEmpty ? null : warnings.join('\n'),
    );
  }

  Future<void> _deleteTempFile(String path) async {
    try {
      final file = File(path);
      if (await file.exists()) {
        await file.delete();
      }
    } catch (_) {
      // فشل الحذف ليس خطأً حرجاً - يترك فقط ملفاً مؤقتاً إضافياً
      // سيُنظّفه النظام لاحقاً من تلقاء نفسه (مجلد cache/temporary).
    }
  }
}
