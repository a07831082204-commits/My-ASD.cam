import 'dart:typed_data';
import 'package:flutter/services.dart';

/// نتيجة فتح الكاميرا: تحتوي على معرّف الـ Texture (لعرض المعاينة الحية)
/// والنطاقات الفعلية المدعومة على جهاز المستخدم الحالي فعلياً - وليست
/// قيماً افتراضية عامة، لأن كل جهاز يختلف عن الآخر بشدة في هذه الحدود.
class NativeCameraCapabilities {
  final int textureId;
  final int isoMin;
  final int isoMax;
  final int shutterMinNanos;
  final int shutterMaxNanos;
  final bool supportsManualSensor;
  final bool hasFlashUnit;
  final bool supportsRaw;

  NativeCameraCapabilities({
    required this.textureId,
    required this.isoMin,
    required this.isoMax,
    required this.shutterMinNanos,
    required this.shutterMaxNanos,
    required this.supportsManualSensor,
    required this.hasFlashUnit,
    required this.supportsRaw,
  });

  factory NativeCameraCapabilities.fromMap(Map<dynamic, dynamic> map) {
    return NativeCameraCapabilities(
      textureId: map['textureId'] as int,
      isoMin: (map['isoMin'] as num).round(),
      isoMax: (map['isoMax'] as num).round(),
      shutterMinNanos: (map['shutterMinNanos'] as num).round(),
      shutterMaxNanos: (map['shutterMaxNanos'] as num).round(),
      supportsManualSensor: map['supportsManualSensor'] as bool? ?? false,
      hasFlashUnit: map['hasFlashUnit'] as bool? ?? false,
      supportsRaw: map['supportsRaw'] as bool? ?? false,
    );
  }
}

/// إطار واحد من قناع الحواف القادم من الكود الأصلي: صورة RGBA صغيرة
/// (عادة حوالي 320px) حيث القنوات R/G/B ثابتة على اللون الأخضر
/// النابض (AppColors.focusGreen)، وقناة A تمثّل قوة الحافة في تلك
/// النقطة (0 = شفاف تماماً، 255 = حافة حادة جداً/مركّزة).
class FocusPeakingFrame {
  final int width;
  final int height;
  final Uint8List rgbaBytes;

  FocusPeakingFrame({
    required this.width,
    required this.height,
    required this.rgbaBytes,
  });
}

/// نتيجة عملية التقاط واحدة. قد تحتوي [jpegPath] فقط، أو [rawPath] فقط،
/// أو كلاهما معاً عند اختيار RAW+JPEG. أيهما null يعني أن تلك الصيغة
/// لم تُطلب أو لم تُنتَج (مثال: RAW غير مدعوم فتحوّل تلقائياً لـ JPEG).
class CapturedPhoto {
  final String? jpegPath;
  final String? rawPath;

  CapturedPhoto({this.jpegPath, this.rawPath});

  factory CapturedPhoto.fromMap(Map<dynamic, dynamic> map) {
    return CapturedPhoto(
      jpegPath: map['jpegPath'] as String?,
      rawPath: map['rawPath'] as String?,
    );
  }
}

/// هذا الكلاس هو الواجهة الوحيدة التي تتحدث مع الكود الأصلي.
/// نفس القناة "com.procamera/manual_camera" مطبّقة بنفس التوقيع تماماً
/// في ManualCameraPlugin.kt (أندرويد) وManualCameraPlugin.swift (iOS)،
/// لذلك هذا الملف لا يحتاج أي فرع خاص بالمنصة (Platform.isIOS).
///
/// ملاحظة صادقة: هذا الجسر يحل محل حزمة camera بالكامل لمسار
/// المعاينة والالتقاط، لأن الاثنين لا يستطيعان فتح نفس الكاميرا
/// في نفس الوقت. أي منطق قديم يعتمد على CameraController من حزمة
/// camera (مثل camera_service.dart) يجب أن يُستبدل بهذا الكلاس
/// عند تفعيل هذا الجسر.
class NativeCameraBridge {
  static const MethodChannel _channel =
      MethodChannel('com.procamera/manual_camera');

  // قناة أحداث منفصلة عمداً عن قناة الأوامر (MethodChannel): بث الإطارات
  // مستمر وعالي التردد نسبياً، بينما الأوامر (فتح/التقاط/ضبط) متقطعة.
  // فصلهما يمنع تزاحم أي منهما مع الآخر على نفس القناة.
  static const EventChannel _focusPeakingChannel =
      EventChannel('com.procamera/focus_peaking_frames');

  NativeCameraCapabilities? capabilities;

  Future<NativeCameraCapabilities> openCamera() async {
    final result = await _channel.invokeMethod('openCamera');
    final caps = NativeCameraCapabilities.fromMap(result as Map);
    capabilities = caps;
    return caps;
  }

  /// [iso] قيمة صحيحة ضمن [capabilities.isoMin, isoMax]
  /// [shutterDenominator] مثال: 125 يعني 1/125 ثانية
  Future<void> setManualExposure({
    required int iso,
    required int shutterDenominator,
  }) async {
    final exposureNanos = (1e9 / shutterDenominator).round();
    await _channel.invokeMethod('setManualExposure', {
      'iso': iso,
      'exposureNanos': exposureNanos,
    });
  }

  Future<void> setAutoExposure() async {
    await _channel.invokeMethod('setAutoExposure');
  }

  /// يفعّل أو يعطّل التورش (إضاءة الفلاش المستمرة). يُهمَل بصمت على
  /// الجانب الأصلي إن كان الجهاز لا يملك وحدة فلاش أصلاً - تحقق من
  /// [NativeCameraCapabilities.hasFlashUnit] قبل إظهار الزر إن أردت
  /// تجربة مستخدم أدق.
  Future<void> setFlashMode(bool torchOn) async {
    await _channel.invokeMethod('setFlashMode', {'torch': torchOn});
  }

  /// [format] يحدد الصيغة الفعلية المطلوبة من الحساس مباشرة:
  /// "jpeg" | "raw" | "rawPlusJpeg". يرجع مسارات الملفات الفعلية على
  /// تخزين الجهاز - قد يحتوي أحد المسارين فقط حسب ما اكتمل فعلياً.
  Future<CapturedPhoto> capturePhoto({
    required String format,
    String? outputDir,
  }) async {
    final result = await _channel.invokeMethod('capturePhoto', {
      'format': format,
      if (outputDir != null) 'outputDir': outputDir,
    });
    return CapturedPhoto.fromMap(result as Map);
  }

  Future<void> closeCamera() async {
    await _channel.invokeMethod('closeCamera');
  }

  /// يُفعّل أو يعطّل بث إطارات التحليل من الجانب الأصلي. مهم جداً
  /// إبقاؤه معطلاً عندما لا تُعرض الطبقة، لأن حساب الحواف يستهلك
  /// معالجة إضافية حتى لو كانت خفيفة نسبياً.
  Future<void> setFocusPeakingEnabled(bool enabled) async {
    await _channel.invokeMethod('setFocusPeakingEnabled', {
      'enabled': enabled,
    });
  }

  /// بث مستمر لأقنعة الحواف الجاهزة أولاً بأول. الاستماع لهذا الـ
  /// Stream يُفعّل تلقائياً onListen في الكود الأصلي، والتوقف عن
  /// الاستماع (cancel) يستدعي onCancel هناك - لذا يكفي عادة استدعاء
  /// setFocusPeakingEnabled(true) قبل الاستماع، والإلغاء عند الانتهاء.
  Stream<FocusPeakingFrame> get focusPeakingFrames {
    return _focusPeakingChannel.receiveBroadcastStream().map((event) {
      final map = event as Map;
      return FocusPeakingFrame(
        width: map['width'] as int,
        height: map['height'] as int,
        rgbaBytes: map['bytes'] as Uint8List,
      );
    });
  }
}
