import 'dart:math' as math;
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import '../models/depth_map.dart';

/// نتيجة الترشيح: خريطة عمق مُنعَّمة بدقة "عمل" وسيطة (وليست دقة
/// الصورة الأصلية الكاملة - انظر التعليق على [JointBilateralUpsampler]
/// لسبب هذا القرار)، مع دوال مساعدة لأخذ عيّنة منها بإحداثيات دقة
/// كاملة عبر استيفاء ثنائي الخط (Bilinear).
class RefinedDepthMap {
  final int width;
  final int height;
  final Float32List values;

  RefinedDepthMap({
    required this.width,
    required this.height,
    required this.values,
  });

  /// يأخذ عيّنة بإحداثيات عائمة (غير صحيحة بالضرورة) عبر استيفاء
  /// ثنائي الخط - يُستخدم لتحويل إحداثيات بكسل الصورة الكاملة
  /// (بعد الترشيح) إلى القيمة المقابلة في هذه الخريطة الأصغر.
  double sampleBilinear(double x, double y) {
    final x0 = x.floor().clamp(0, width - 1);
    final x1 = (x0 + 1).clamp(0, width - 1);
    final y0 = y.floor().clamp(0, height - 1);
    final y1 = (y0 + 1).clamp(0, height - 1);
    final fx = (x - x0).clamp(0.0, 1.0);
    final fy = (y - y0).clamp(0.0, 1.0);

    final v00 = values[y0 * width + x0];
    final v10 = values[y0 * width + x1];
    final v01 = values[y1 * width + x0];
    final v11 = values[y1 * width + x1];

    final top = v00 * (1 - fx) + v10 * fx;
    final bottom = v01 * (1 - fx) + v11 * fx;
    return top * (1 - fy) + bottom * fy;
  }
}

/// يُنفّذ Joint Bilateral Upsampling: يُنعّم خريطة عمق خشنة (256×256
/// من نموذج تقدير العمق) بالاعتماد على حواف صورة "دليل" (Guide) عالية
/// الدقة - وهي الصورة الملتقطة نفسها - كمرجع لموضع الحواف الحقيقية،
/// بدل الاعتماد على حواف خريطة العمق الخشنة نفسها (وهي ما كان يُنتج
/// الحواف الكتلية "blocky" في التكبير الساذج السابق).
///
/// الفكرة الجوهرية: لكل بكسل في خريطة العمق المُكبَّرة، نأخذ متوسطاً
/// مرجَّحاً لجيرانه، حيث الوزن يعتمد على أمرين معاً:
///   1. القرب المكاني (Spatial): جيران أقرب مكانياً وزنهم أعلى.
///   2. تشابه اللومينانس في صورة الدليل (Range): جيران بلون/سطوع
///      مشابه في الصورة الأصلية وزنهم أعلى - وهذا بالضبط ما يجعل
///      الترشيح "يتوقف" عند الحواف الحقيقية في الصورة (تغيّر لوني
///      حاد) بدل تسريب قيم العمق عبرها.
///
/// ## قرار أداء حاسم ومتعمَّد: دقة "عمل" محدودة، وليست الدقة الكاملة
/// تطبيق هذا الترشيح مباشرة على دقة صورة كاملة (قد تتجاوز 4000×3000)
/// غير عملي زمنياً بكود Dart خالص على معالج جوال: نافذة 9×9 على 12
/// مليون بكسل تعني أكثر من 900 مليون عملية حسابية. الحل المعياري
/// المتّبع هنا: تنفيذ الترشيح الكامل على نسخة مصغَّرة من صورة الدليل
/// (أطول ضلع = [_workingMaxDimension])، ثم إعادة تكبير خريطة العمق
/// المُنعَّمة الناتجة للدقة الكاملة عبر استيفاء ثنائي الخط بسيط عند
/// التركيب النهائي. بما أن الترشيح الموجَّه بالحواف الحقيقية تم
/// بالفعل عند دقة العمل، فإن الاستيفاء الثنائي الخط اللاحق لا يُعيد
/// إنتاج أي حواف كتلية - هو فقط يُنعّم انتقالاً أصلاً سلساً وواعياً
/// بالحواف، وليس قفزة قيمة خامة من خريطة 256×256 كما في السابق.
class JointBilateralUpsampler {
  static const int _workingMaxDimension = 1024;
  static const int _spatialRadius = 4; // نافذة تقريبية 9×9
  static const double _sigmaSpatial = 3.0;
  static const double _sigmaRange = 25.0; // بمقياس فرق لومينانس 0-255

  static RefinedDepthMap upsample({
    required DepthMap lowResDepth,
    required img.Image guideImage,
  }) {
    final longestSide = math.max(guideImage.width, guideImage.height);
    final scale =
        longestSide > _workingMaxDimension ? _workingMaxDimension / longestSide : 1.0;

    final workingGuide = scale < 1.0
        ? img.copyResize(
            guideImage,
            width: (guideImage.width * scale).round(),
            height: (guideImage.height * scale).round(),
          )
        : guideImage;

    final w = workingGuide.width;
    final h = workingGuide.height;

    // تكبير أولي بسيط لخريطة العمق الخام لدقة العمل - مجرد نقطة
    // انطلاق ستُعاد صياغتها بالكامل في الترشيح التالي، وليست النتيجة
    // النهائية.
    final initial = _bilinearResizeDepth(lowResDepth, w, h);
    final guideLuma = _computeLuminance(workingGuide);

    // تحسين أداء جوهري: وزن القرب المكاني يعتمد فقط على الإزاحة
    // (dx, dy) وليس على موضع البكسل نفسه - لذلك يُحسب مرة واحدة فقط
    // هنا (81 قيمة كحد أقصى لنافذة 9×9)، بدل استدعاء exp() آلاف
    // المرات لكل بكسل.
    final spatialWeights = _precomputeSpatialWeights();

    // تحسين أداء ثانٍ: وزن التشابه اللوني يعتمد فقط على *فرق* اللومينانس
    // بين -255 و255، وهو مدى محدود ومعروف مسبقاً - نحسبه كجدول بحث
    // (Lookup Table) مرة واحدة بدل استدعاء exp() لكل زوج بكسلات.
    // هذان التحسينان معاً يحوّلان الحلقة الداخلية الكاملة إلى عمليات
    // ضرب وجمع وبحث في مصفوفة فقط - أهم فرق عملي بين تطبيق بطيء جداً
    // (عدة ثوانٍ) وتطبيق عملي (أقل من نصف ثانية) لهذا النوع من الترشيح.
    final rangeWeightTable = _precomputeRangeWeightTable();

    final refined = Float32List(w * h);

    for (int y = 0; y < h; y++) {
      for (int x = 0; x < w; x++) {
        double weightSum = 0;
        double valueSum = 0;
        final centerLuma = guideLuma[y * w + x];

        var weightIndex = 0;
        for (int dy = -_spatialRadius; dy <= _spatialRadius; dy++) {
          final ny = (y + dy).clamp(0, h - 1);
          for (int dx = -_spatialRadius; dx <= _spatialRadius; dx++) {
            final nx = (x + dx).clamp(0, w - 1);

            final lumaDiff = (guideLuma[ny * w + nx] - centerLuma).round();
            final rangeWeight = rangeWeightTable[(lumaDiff + 255).clamp(0, 510)];
            final weight = spatialWeights[weightIndex] * rangeWeight;

            weightSum += weight;
            valueSum += weight * initial[ny * w + nx];
            weightIndex++;
          }
        }

        refined[y * w + x] =
            weightSum > 1e-6 ? valueSum / weightSum : initial[y * w + x];
      }
    }

    return RefinedDepthMap(width: w, height: h, values: refined);
  }

  static List<double> _precomputeSpatialWeights() {
    final weights = <double>[];
    for (int dy = -_spatialRadius; dy <= _spatialRadius; dy++) {
      for (int dx = -_spatialRadius; dx <= _spatialRadius; dx++) {
        final dist2 = (dx * dx + dy * dy).toDouble();
        weights.add(math.exp(-dist2 / (2 * _sigmaSpatial * _sigmaSpatial)));
      }
    }
    return weights;
  }

  static Float32List _precomputeRangeWeightTable() {
    // 511 مدخلاً تغطي كل فرق لومينانس ممكن بين -255 و+255
    final table = Float32List(511);
    for (int diff = -255; diff <= 255; diff++) {
      table[diff + 255] =
          math.exp(-(diff * diff) / (2 * _sigmaRange * _sigmaRange));
    }
    return table;
  }

  static Float32List _bilinearResizeDepth(DepthMap depth, int targetW, int targetH) {
    final result = Float32List(targetW * targetH);
    final scaleX = depth.width / targetW;
    final scaleY = depth.height / targetH;

    for (int y = 0; y < targetH; y++) {
      final srcYf = (y + 0.5) * scaleY - 0.5;
      final y0 = srcYf.floor().clamp(0, depth.height - 1);
      final y1 = (y0 + 1).clamp(0, depth.height - 1);
      final fy = (srcYf - y0).clamp(0.0, 1.0);

      for (int x = 0; x < targetW; x++) {
        final srcXf = (x + 0.5) * scaleX - 0.5;
        final x0 = srcXf.floor().clamp(0, depth.width - 1);
        final x1 = (x0 + 1).clamp(0, depth.width - 1);
        final fx = (srcXf - x0).clamp(0.0, 1.0);

        final v00 = depth.at(x0, y0);
        final v10 = depth.at(x1, y0);
        final v01 = depth.at(x0, y1);
        final v11 = depth.at(x1, y1);

        final top = v00 * (1 - fx) + v10 * fx;
        final bottom = v01 * (1 - fx) + v11 * fx;
        result[y * targetW + x] = top * (1 - fy) + bottom * fy;
      }
    }
    return result;
  }

  static Float32List _computeLuminance(img.Image image) {
    final result = Float32List(image.width * image.height);
    for (int y = 0; y < image.height; y++) {
      for (int x = 0; x < image.width; x++) {
        final p = image.getPixel(x, y);
        result[y * image.width + x] =
            0.299 * p.r + 0.587 * p.g + 0.114 * p.b;
      }
    }
    return result;
  }
}
