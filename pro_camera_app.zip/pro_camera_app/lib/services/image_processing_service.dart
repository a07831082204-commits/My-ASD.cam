import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import '../models/camera_settings.dart';
import '../models/depth_map.dart';
import 'joint_bilateral_upsampler.dart';

/// هذه الخدمة يجب أن تُستدعى عبر compute() من الواجهة (انظر
/// [ImageProcessingRequest] و[runImageProcessingIsolate] أسفل هذا
/// الملف)، لأن معالجة صورة كاملة البكسلات + ترشيح Joint Bilateral
/// معاً عملية ثقيلة فعلاً ويجب ألا تُجمّد واجهة المستخدم إطلاقاً.
///
/// تحديث: أصبح Chiaroscuro يدعم الآن نسختين:
/// 1. [_applyChiaroscuroWithDepth]: تستخدم [DepthMap] فعلية من نموذج
///    تقدير عمق (MiDaS-small عبر DepthEstimationService)، مُنعَّمة
///    بالحواف الحقيقية للصورة عبر [JointBilateralUpsampler] بدل
///    التكبير الساذج (nearest-neighbor) السابق، لتوزيع الإضاءة حسب
///    المسافة الفعلية للأجسام دون حواف كتلية عند حدود الموضوع.
/// 2. [_applyChiaroscuro]: النسخة الاحتياطية القديمة المعتمدة على
///    السطوع فقط (بدون أي معرفة بالعمق الفعلي)، تُستخدم تلقائياً كلما
///    كان نموذج العمق غير متاح (فشل تحميله، أو لم يُضَف ملفه أصلاً)
///    - لضمان أن الميزة لا تتعطل بالكامل بغياب النموذج.
class ImageProcessingService {
  /// نقطة الدخول الرئيسية: تطبق فلتر سينمائي + تقليل ضوضاء اختياري.
  /// [depthMap] اختياري تماماً - مرِّرها فقط عند توفر نموذج تقدير عمق
  /// فعلي؛ عند تركها null يُستخدم تلقائياً تقريب السطوع القديم.
  static Uint8List processImage({
    required Uint8List rawBytes,
    required CinematicFilter filter,
    required bool reduceNoise,
    DepthMap? depthMap,
  }) {
    img.Image? image = img.decodeImage(rawBytes);
    if (image == null) return rawBytes;

    if (reduceNoise) {
      image = _reduceNoisePreservingEdges(image);
    }

    switch (filter) {
      case CinematicFilter.chiaroscuro:
        image = depthMap != null
            ? _applyChiaroscuroWithDepth(image, depthMap)
            : _applyChiaroscuro(image);
        break;
      case CinematicFilter.warmFilm:
        image = _applyWarmFilm(image);
        break;
      case CinematicFilter.coolTeal:
        image = _applyCoolTeal(image);
        break;
      case CinematicFilter.noir:
        image = img.grayscale(image);
        image = img.contrast(image, contrast: 130);
        break;
      case CinematicFilter.none:
        break;
    }

    return Uint8List.fromList(img.encodeJpg(image, quality: 95));
  }

  /// تقليل ضوضاء "ذكي بسيط": يستخدم فلتر Gaussian خفيف جداً على
  /// نسخة من الصورة، ثم يمزجها مع الأصل مع الحفاظ على الحواف عبر
  /// قناع Sobel (كشف حواف) - هذا يحاكي فكرة Bilateral Filter
  /// بتكلفة حسابية أقل بكثير، مناسب للتشغيل الفوري على الجوال.
  static img.Image _reduceNoisePreservingEdges(img.Image src) {
    final blurred = img.gaussianBlur(img.Image.from(src), radius: 2);
    final edges = img.sobel(img.Image.from(src));

    for (int y = 0; y < src.height; y++) {
      for (int x = 0; x < src.width; x++) {
        final edgeStrength = img.getLuminance(edges.getPixel(x, y)) / 255.0;
        // كلما زادت قوة الحافة، اعتمدنا أكثر على البكسل الأصلي الحاد
        // وكلما قلّت، اعتمدنا على النسخة المموّهة (تقليل الضوضاء).
        final orig = src.getPixel(x, y);
        final blur = blurred.getPixel(x, y);
        final mixFactor = edgeStrength.clamp(0.0, 1.0);

        final r = (orig.r * mixFactor + blur.r * (1 - mixFactor)).round();
        final g = (orig.g * mixFactor + blur.g * (1 - mixFactor)).round();
        final b = (orig.b * mixFactor + blur.b * (1 - mixFactor)).round();

        src.setPixelRgb(x, y, r, g, b);
      }
    }
    return src;
  }

  /// Chiaroscuro الحقيقي المعتمد على العمق: الأجسام الأقرب للكاميرا
  /// (عادة الموضوع الرئيسي) تُضاء وتحافظ على تفاصيلها، بينما الخلفية
  /// الأبعد تُدفَع تدريجياً نحو الظل الكامل - هذا هو جوهر أسلوب
  /// Chiaroscuro السينمائي الأصيل (إضاءة تتبع الموضوع، لا السطوع
  /// العشوائي في الصورة كما في النسخة الاحتياطية أدناه).
  ///
  /// تحديث: خريطة العمق الخام (256×256) تُنعَّم الآن بحواف الصورة
  /// الحقيقية عبر [JointBilateralUpsampler] قبل استخدامها، بدل تكبيرها
  /// مباشرة بنسبة أقرب جار (nearest-neighbor) كما كانت النسخة السابقة -
  /// ما كان يُنتج حوافاً كتلية واضحة عند حدود الموضوع الحادة في الصور
  /// عالية الدقة. التفاصيل الكاملة لقرارات الأداء (دقة العمل المحدودة،
  /// جداول البحث المحسوبة مسبقاً) موثّقة في تعليقات ذلك الملف مباشرة.
  static img.Image _applyChiaroscuroWithDepth(
    img.Image image,
    DepthMap depthMap,
  ) {
    image = img.adjustColor(image, contrast: 1.2, saturation: 0.95);

    final refined = JointBilateralUpsampler.upsample(
      lowResDepth: depthMap,
      guideImage: image,
    );

    // نسبة تحويل إحداثيات بكسل الصورة الكاملة إلى دقة خريطة العمق
    // المُنعَّمة (التي قد تكون أصغر من الصورة الأصلية - انظر
    // _workingMaxDimension في JointBilateralUpsampler)، ثم نأخذ عيّنة
    // بالاستيفاء الثنائي الخط بدل القفز المباشر بين البكسلات.
    final scaleX = refined.width / image.width;
    final scaleY = refined.height / image.height;

    for (int y = 0; y < image.height; y++) {
      final sampleY = y * scaleY;
      for (int x = 0; x < image.width; x++) {
        final sampleX = x * scaleX;

        // 1.0 = أقرب نقطة (الموضوع)، 0.0 = أبعد نقطة (الخلفية)
        final depth = refined.sampleBilinear(sampleX, sampleY);

        // منحنى إضاءة يتراوح تقريباً بين 0.5× (خلفية مُعتِمة بقوة)
        // و1.15× (موضوع مُضاء قليلاً فوق سطوعه الأصلي) - يحاكي إضاءة
        // استوديو موجَّهة (Spotlight) تتبع عمق المشهد فعلياً.
        final lightFactor = 0.5 + (depth * 0.65);

        final p = image.getPixel(x, y);
        image.setPixelRgb(
          x,
          y,
          (p.r * lightFactor).clamp(0, 255).round(),
          (p.g * lightFactor).clamp(0, 255).round(),
          (p.b * lightFactor).clamp(0, 255).round(),
        );
      }
    }

    return image;
  }

  /// Chiaroscuro: تباين قوي بين الأضواء والظلال + تعميق الظلال
  /// + رفع بسيط للهايلايت، بدون فقدان التفاصيل الحادة.
  /// نسخة احتياطية تُستخدم فقط عند غياب نموذج تقدير العمق (انظر
  /// [_applyChiaroscuroWithDepth] للنسخة الأدق التي تعتمد على العمق
  /// الفعلي للمشهد بدل السطوع وحده).
  static img.Image _applyChiaroscuro(img.Image image) {
    image = img.adjustColor(
      image,
      contrast: 1.35,
      brightness: 0.95,
      saturation: 0.9,
    );
    // منحنى تظليل: نخفض الأجزاء الداكنة أكثر لخلق تباين درامي
    for (int y = 0; y < image.height; y++) {
      for (int x = 0; x < image.width; x++) {
        final p = image.getPixel(x, y);
        final lum = img.getLuminance(p) / 255.0;
        double factor = lum < 0.35 ? 0.75 : 1.05;
        image.setPixelRgb(
          x,
          y,
          (p.r * factor).clamp(0, 255).round(),
          (p.g * factor).clamp(0, 255).round(),
          (p.b * factor).clamp(0, 255).round(),
        );
      }
    }
    return image;
  }

  static img.Image _applyWarmFilm(img.Image image) {
    return img.adjustColor(
      image,
      contrast: 1.1,
      saturation: 1.05,
      brightness: 1.02,
    ).also((i) => img.colorOffset(i, red: 12, green: 4, blue: -10));
  }

  static img.Image _applyCoolTeal(img.Image image) {
    final adjusted = img.adjustColor(image, contrast: 1.15, saturation: 0.95);
    return img.colorOffset(adjusted, red: -8, green: 2, blue: 14);
  }
}

/// إضافة صغيرة (extension) لتسلسل العمليات بشكل أنظف (Fluent style)
extension _Also<T> on T {
  T also(void Function(T) action) {
    action(this);
    return this;
  }
}

/// حزمة كل ما تحتاجه [runImageProcessingIsolate] لمعالجة صورة واحدة،
/// بحيث يمكن تمريرها كاملة كوسيط واحد إلى compute() - الذي يتطلب
/// دالة تأخذ معاملاً واحداً بالضبط. كل الحقول هنا قابلة للنقل بين
/// Isolates بأمان (Uint8List وFloat32List وأنواع بدائية فقط، بلا أي
/// كائنات معقدة أو مؤشرات ذاكرة أصلية).
class ImageProcessingRequest {
  final Uint8List rawBytes;
  final CinematicFilter filter;
  final bool reduceNoise;
  final DepthMap? depthMap;

  const ImageProcessingRequest({
    required this.rawBytes,
    required this.filter,
    required this.reduceNoise,
    this.depthMap,
  });
}

/// دالة عليا (top-level) - شرط أساسي في Flutter لأي دالة تُمرَّر إلى
/// compute()، لا يمكن أن تكون method داخل كلاس أو closure يلتقط حالة
/// خارجية. هذه الدالة هي نقطة الدخول الفعلية التي تُشغَّل بالكامل
/// (فك الترميز + تقليل الضوضاء + الترشيح الثنائي الموجَّه + الفلتر +
/// إعادة الترميز) في Isolate خلفي منفصل تماماً عن واجهة المستخدم.
///
/// الاستخدام من الواجهة (مثال في camera_screen.dart):
/// ```dart
/// final processed = await compute(
///   runImageProcessingIsolate,
///   ImageProcessingRequest(
///     rawBytes: bytes,
///     filter: settings.activeFilter,
///     reduceNoise: settings.isNoiseReductionEnabled,
///     depthMap: depthMap,
///   ),
/// );
/// ```
Uint8List runImageProcessingIsolate(ImageProcessingRequest request) {
  return ImageProcessingService.processImage(
    rawBytes: request.rawBytes,
    filter: request.filter,
    reduceNoise: request.reduceNoise,
    depthMap: request.depthMap,
  );
}
