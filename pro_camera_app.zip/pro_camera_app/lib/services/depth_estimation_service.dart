import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';
import '../models/depth_map.dart';

/// خدمة تقدير عمق أحادي الصورة (Monocular Depth Estimation) باستخدام
/// نموذج MiDaS v2.1-small المُصدَّر إلى TFLite - نفس النموذج المستخدم
/// في تطبيقات مرجعية معروفة (مثال: mobile/android في مستودع MiDaS
/// الرسمي على GitHub لـ isl-org). هذا النموذج تحديداً (وليس MiDaS
/// الكبير) لأنه مصمم للعمل بسرعة معقولة على معالجات الجوال
/// (~30fps على شرائح NPU حديثة، وأبطأ بكثير على المعالج العام فقط).
///
/// ملاحظة صادقة وحاسمة: **ملف النموذج (.tflite) غير مُرفَق في هذا
/// المستودع** لأنه ملف ثنائي كبير (~15-20 ميجابايت) لا يصح تضمينه
/// تلقائياً بدون تحقق المطوّر من ترخيصه ومصدره بنفسه. راجع
/// `assets/models/README.md` لخطوات تحميله من مصدر رسمي موثّق
/// (TensorFlow Hub أو Kaggle). حتى إضافته، هذه الخدمة تفشل بأمان
/// (isAvailable = false) ويعتمد التطبيق تلقائياً على نسخة Chiaroscuro
/// الأبسط المعتمدة على السطوع فقط في ImageProcessingService.
class DepthEstimationService {
  static const String _modelAssetPath = 'assets/models/model_opt.tflite';

  // أبعاد إدخال/إخراج MiDaS-small القياسية - موثّقة رسمياً في
  // TensorFlow Hub: صورة RGB مربعة 256×256، وخرج خريطة عمق بنفس الدقة.
  static const int _inputSize = 256;

  Interpreter? _interpreter;
  IsolateInterpreter? _isolateInterpreter;

  bool isAvailable = false;

  /// يحاول تحميل النموذج من الأصول (assets). الفشل هنا متوقع تماماً
  /// طالما لم يُضَف ملف .tflite الفعلي بعد - لا يُعتبر خطأ حرجاً في
  /// أي مكان آخر في التطبيق، فقط تعطيل صامت لهذه الميزة تحديداً.
  Future<void> loadModel() async {
    try {
      final interpreter = await Interpreter.fromAsset(_modelAssetPath);

      // IsolateInterpreter يُشغّل الاستدلال الفعلي في Isolate منفصل
      // تماماً عن الواجهة، حتى لا تتجمد الشاشة أثناء المعالجة (التي
      // قد تستغرق 100-400 مللي ثانية على معالج عام بدون تسريع NPU/GPU).
      final isolateInterpreter = await IsolateInterpreter.create(
        address: interpreter.address,
      );

      _interpreter = interpreter;
      _isolateInterpreter = isolateInterpreter;
      isAvailable = true;
    } catch (e) {
      debugPrint(
        'تعذر تحميل نموذج تقدير العمق (متوقع إن لم يُضَف الملف بعد): $e',
      );
      isAvailable = false;
    }
  }

  /// يقدّر خريطة عمق لصورة JPEG مُرمَّزة. يرجع null إن كان النموذج
  /// غير محمَّل، أو إن فشل فك ترميز الصورة نفسها.
  Future<DepthMap?> estimateDepth(Uint8List jpegBytes) async {
    final isolateInterpreter = _isolateInterpreter;
    if (!isAvailable || isolateInterpreter == null) return null;

    final decoded = img.decodeImage(jpegBytes);
    if (decoded == null) return null;

    // النموذج يتوقع دقة ثابتة 256×256 بغض النظر عن دقة التقاط
    // الصورة الفعلية؛ خريطة العمق الناتجة تُعاد تكبيرها لاحقاً في
    // ImageProcessingService لتغطية الصورة الكاملة.
    final resized = img.copyResize(
      decoded,
      width: _inputSize,
      height: _inputSize,
    );

    // تطبيع [-1, 1] لكل قناة لون - هذا هو التطبيع المؤكَّد فعلياً من
    // كود المعالجة المسبقة الرسمي لملف model_opt.tflite تحديداً
    // (مصدر isl-org/MiDaS Releases v2_1)، وليس [0,1] كما في افتراض
    // سابق أقل دقة. إن استبدلت الملف بتصدير آخر لاحقاً (مثال: نسخة
    // TensorFlow Hub لايت)، تحقّق من تطبيعه الخاص أولاً - قد يختلف.
    final input = [
      List.generate(
        _inputSize,
        (y) => List.generate(_inputSize, (x) {
          final pixel = resized.getPixel(x, y);
          return [
            (pixel.r / 127.5) - 1.0,
            (pixel.g / 127.5) - 1.0,
            (pixel.b / 127.5) - 1.0,
          ];
        }),
      ),
    ];

    final output = [
      List.generate(_inputSize, (_) => List<double>.filled(_inputSize, 0.0)),
    ];

    await isolateInterpreter.run(input, output);

    return _normalizeOutput(output[0]);
  }

  /// يحوّل خرج النموذج الخام (قيم غير مُقيَّدة بمدى محدد) إلى
  /// [DepthMap] مُطبَّعة بالكامل إلى [0, 1]، لأن MiDaS يُخرج عمقاً
  /// نسبياً بمدى مختلف لكل صورة - التطبيع لكل صورة على حدة هو
  /// السلوك الصحيح والموصى به رسمياً لهذا النوع من النماذج.
  DepthMap _normalizeOutput(List<List<double>> raw) {
    var minVal = double.infinity;
    var maxVal = double.negativeInfinity;

    for (final row in raw) {
      for (final v in row) {
        if (v < minVal) minVal = v;
        if (v > maxVal) maxVal = v;
      }
    }

    final range = (maxVal - minVal).abs() < 1e-6 ? 1.0 : (maxVal - minVal);
    final values = Float32List(_inputSize * _inputSize);

    for (var y = 0; y < _inputSize; y++) {
      for (var x = 0; x < _inputSize; x++) {
        values[y * _inputSize + x] = (raw[y][x] - minVal) / range;
      }
    }

    return DepthMap(width: _inputSize, height: _inputSize, values: values);
  }

  Future<void> dispose() async {
    await _isolateInterpreter?.close();
    _interpreter?.close();
    isAvailable = false;
  }
}
