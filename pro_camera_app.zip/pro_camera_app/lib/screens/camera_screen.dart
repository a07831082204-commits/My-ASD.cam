import 'dart:io';
import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/camera_settings.dart';
import '../services/native_camera_bridge.dart';
import '../services/image_processing_service.dart';
import '../services/gallery_service.dart';
import '../services/depth_estimation_service.dart';
import '../models/depth_map.dart';
import '../theme/app_theme.dart';
import '../widgets/top_bar.dart';
import '../widgets/bottom_controls.dart';
import '../widgets/focus_peaking_overlay.dart';

/// ملاحظة مهمة عن هذا التحديث:
/// هذه الشاشة تعرض المعاينة عبر Texture حقيقي قادم من الكود الأصلي
/// (Camera2 على أندرويد / AVFoundation على iOS)، بدل ودجت
/// CameraPreview من حزمة camera. هذا هو الثمن الحقيقي للحصول على
/// تحكم فعلي وصحيح بـ ISO وسرعة الغالق: لا يمكن الجمع بين حزمة
/// camera وهذا الجسر على نفس الكاميرا في نفس الوقت.
///
/// تحديث لاحق: طبقة FocusPeakingOverlay أصبحت الآن متوافقة تماماً
/// مع هذا الجسر، لأنها تستقبل أقنعة الحواف عبر EventChannel مخصص
/// ("com.procamera/focus_peaking_frames") يُغذّى مباشرة من نفس
/// الكود الأصلي (Camera2/AVFoundation)، بدل الاعتماد على
/// CameraController.startImageStream() من حزمة camera كما كانت
/// النسخة الأولى.
class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  final NativeCameraBridge _bridge = NativeCameraBridge();
  final GalleryService _galleryService = GalleryService();
  final DepthEstimationService _depthService = DepthEstimationService();
  NativeCameraCapabilities? _capabilities;
  bool _uiVisible = true;
  String? _lastCapturedPath;
  String? _lastRawPath;
  bool _isProcessing = false;
  String? _errorMessage;
  String? _statusMessage;

  @override
  void initState() {
    super.initState();
    _init();
    // يُحمَّل بالتوازي مع فتح الكاميرا وليس بالتسلسل بعدها، لأن
    // تحميل نموذج TFLite (حتى الفاشل منه لعدم وجود الملف) قد يستغرق
    // بضع مللي ثوانٍ لا داعي لانتظارها قبل عرض المعاينة الحية للمستخدم.
    // فشل التحميل هنا متوقع تماماً ولا يُعرض كخطأ للمستخدم - فقط
    // اعتماد صامت على النسخة الاحتياطية من Chiaroscuro عند الالتقاط.
    _depthService.loadModel();
  }

  Future<void> _init() async {
    try {
      final caps = await _bridge.openCamera();
      if (!mounted) return;
      setState(() => _capabilities = caps);

      if (!caps.supportsManualSensor) {
        setState(() {
          _errorMessage =
              'هذا الجهاز لا يدعم التحكم اليدوي الحقيقي بالحساس '
              '(MANUAL_SENSOR). سيعمل التطبيق بوضع تلقائي فقط.';
        });
      }
    } on Exception catch (e) {
      setState(() => _errorMessage = 'فشل فتح الكاميرا: $e');
    }
  }

  /// يُستدعى في كل مرة يغيّر فيها المستخدم ISO أو سرعة الغالق من العجلات
  Future<void> _applyManualExposureIfNeeded(CameraSettings settings) async {
    if (_capabilities == null || !_capabilities!.supportsManualSensor) return;

    if (settings.isManualModeEnabled) {
      // تقريب ISO ضمن المدى الفعلي المدعوم على هذا الجهاز تحديداً
      final clampedIso = settings.iso.clamp(
        _capabilities!.isoMin,
        _capabilities!.isoMax,
      );
      await _bridge.setManualExposure(
        iso: clampedIso,
        shutterDenominator: settings.shutterSpeedDenominator,
      );
    } else {
      await _bridge.setAutoExposure();
    }
  }

  String _formatToWireString(CaptureFormat format) {
    switch (format) {
      case CaptureFormat.jpeg:
        return 'jpeg';
      case CaptureFormat.raw:
        return 'raw';
      case CaptureFormat.rawPlusJpeg:
        return 'rawPlusJpeg';
    }
  }

  Future<void> _handleFlashToggle(CameraSettings settings) async {
    settings.toggleFlash();
    await _bridge.setFlashMode(settings.isFlashOn);
  }

  Future<void> _handleCapture() async {
    final settings = context.read<CameraSettings>();

    if (settings.captureFormat != CaptureFormat.jpeg &&
        _capabilities != null &&
        !_capabilities!.supportsRaw) {
      setState(() {
        _errorMessage =
            'هذا الجهاز لا يدعم RAW فعلياً على مستوى الحساس. '
            'تم الالتقاط بصيغة JPEG بدلاً منه تلقائياً.';
      });
    }

    setState(() => _isProcessing = true);

    try {
      final captured = await _bridge.capturePhoto(
        format: _formatToWireString(settings.captureFormat),
      );

      // الفلاتر السينمائية وتقليل الضوضاء تُطبَّق على JPEG فقط، لأن
      // الهدف الكامل من RAW هو الاحتفاظ ببيانات الحساس الخام دون أي
      // معالجة - أي تعديل على ملف DNG هنا يُبطل الغرض من اختياره أصلاً.
      if (captured.jpegPath != null) {
        final bytes = await File(captured.jpegPath!).readAsBytes();

        // نُشغّل نموذج تقدير العمق فقط عند الحاجة الفعلية له (فلتر
        // Chiaroscuro مُفعَّل + النموذج مُحمَّل بنجاح)، تجنباً لتكلفة
        // استدلال إضافية لا طائل منها مع بقية الفلاتر.
        DepthMap? depthMap;
        if (settings.activeFilter == CinematicFilter.chiaroscuro &&
            _depthService.isAvailable) {
          depthMap = await _depthService.estimateDepth(bytes);
        }

        final processed = await compute(
          runImageProcessingIsolate,
          ImageProcessingRequest(
            rawBytes: bytes,
            filter: settings.activeFilter,
            reduceNoise: settings.isNoiseReductionEnabled,
            depthMap: depthMap,
          ),
        );
        await File(captured.jpegPath!).writeAsBytes(processed);
      }

      setState(() {
        // الصورة المصغّرة تعرض JPEG فقط لأن Flutter لا يملك ديكودر DNG
        // مدمجاً؛ عند التقاط RAW فقط بلا JPEG مرافق، يبقى مسار المصغّرة
        // فارغاً عمداً بدل محاولة عرض ملف لا يمكن فك ترميزه كصورة.
        _lastCapturedPath = captured.jpegPath;
        if (captured.rawPath != null) _lastRawPath = captured.rawPath;
      });

      // نقل الملفات للمعرض الدائم فور الالتقاط، تماماً كسلوك أي تطبيق
      // كاميرا حقيقي - الصورة لا تُعتبر "محفوظة" فعلياً وهي لا تزال في
      // مجلد مؤقت قد يحذفه النظام في أي لحظة.
      try {
        final galleryResult = await _galleryService.saveCapturedFiles(
          jpegPath: captured.jpegPath,
          rawPath: captured.rawPath,
        );

        if (galleryResult.warning != null) {
          setState(() => _errorMessage = galleryResult.warning);
        } else {
          _showTransientStatus('تم الحفظ في معرض الصور (ألبوم Pro Camera)');
        }
      } on GalleryPermissionDeniedException catch (e) {
        setState(() => _errorMessage = e.toString());
      }
    } catch (e) {
      setState(() => _errorMessage = 'فشل الالتقاط: $e');
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  /// رسالة نجاح مؤقتة تختفي تلقائياً، بدل ترك تأكيد الحفظ ظاهراً إلى
  /// الأبد أو الاعتماد فقط على غياب رسالة خطأ (وهو أمر غامض للمستخدم).
  void _showTransientStatus(String message) {
    setState(() => _statusMessage = message);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted && _statusMessage == message) {
        setState(() => _statusMessage = null);
      }
    });
  }

  @override
  void dispose() {
    _bridge.closeCamera();
    _depthService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_capabilities == null) {
      return Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: _errorMessage != null
              ? Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    _errorMessage!,
                    style: const TextStyle(color: AppColors.textPrimary),
                    textAlign: TextAlign.center,
                  ),
                )
              : const CircularProgressIndicator(color: AppColors.gold),
        ),
      );
    }

    // نستمع لتغييرات الإعدادات لتطبيقها فوراً على الكاميرا الفعلية
    final settings = context.watch<CameraSettings>();
    _applyManualExposureIfNeeded(settings);

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Texture(textureId: _capabilities!.textureId),

          FocusPeakingOverlay(
            bridge: _bridge,
            isEnabled: settings.isFocusPeakingEnabled,
          ),

          if (_statusMessage != null)
            Positioned(
              top: 90,
              left: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.gold.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _statusMessage!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),

          if (_errorMessage != null)
            Positioned(
              top: 90,
              left: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.gold),
                ),
                child: Text(
                  _errorMessage!,
                  style: const TextStyle(color: AppColors.textPrimary, fontSize: 12),
                ),
              ),
            ),

          if (_isProcessing)
            const Positioned.fill(
              child: ColoredBox(
                color: Color(0x66000000),
                child: Center(
                  child: CircularProgressIndicator(color: AppColors.gold),
                ),
              ),
            ),

          if (_uiVisible)
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TopBar(
                  onToggleVisibility: () => setState(() => _uiVisible = false),
                  onFlashTap: () => _handleFlashToggle(settings),
                ),
                BottomControls(
                  onCapture: _handleCapture,
                  lastThumbnailPath: _lastCapturedPath,
                  hasRawFile: _lastRawPath != null,
                ),
              ],
            )
          else
            Positioned(
              top: 40,
              right: 16,
              child: SafeArea(
                child: IconButton(
                  icon: const Icon(Icons.visibility, color: AppColors.gold),
                  onPressed: () => setState(() => _uiVisible = true),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
