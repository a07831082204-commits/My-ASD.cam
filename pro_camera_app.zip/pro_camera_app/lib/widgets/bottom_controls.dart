import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/camera_settings.dart';
import '../theme/app_theme.dart';
import 'manual_control_wheel.dart';

class BottomControls extends StatelessWidget {
  final VoidCallback onCapture;
  final String? lastThumbnailPath;
  final bool hasRawFile;

  const BottomControls({
    super.key,
    required this.onCapture,
    this.lastThumbnailPath,
    this.hasRawFile = false,
  });

  static const List<int> isoValues = [50, 100, 200, 400, 800, 1600, 3200];
  static const List<int> shutterDenominators = [
    2000,
    1000,
    500,
    250,
    125,
    60,
    30,
    15
  ];

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<CameraSettings>();

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // عجلات التحكم اليدوي تظهر فقط عند تفعيل الوضع اليدوي
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 250),
          child: settings.isManualModeEnabled
              ? _ManualWheelsRow(settings: settings)
              : const SizedBox(height: 0),
        ),
        const SizedBox(height: 10),
        _FilterStrip(settings: settings),
        const SizedBox(height: 10),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _Thumbnail(path: lastThumbnailPath, hasRawFile: hasRawFile),
              _ShutterButton(onTap: onCapture),
              _ManualModeToggle(settings: settings),
            ],
          ),
        ),
      ],
    );
  }
}

class _ManualWheelsRow extends StatelessWidget {
  final CameraSettings settings;
  const _ManualWheelsRow({required this.settings});

  @override
  Widget build(BuildContext context) {
    final isoStrings =
        BottomControls.isoValues.map((v) => 'ISO $v').toList();
    final shutterStrings =
        BottomControls.shutterDenominators.map((v) => '1/$v').toList();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          Expanded(
            child: ManualControlWheel(
              label: 'ISO',
              values: isoStrings,
              selectedIndex: BottomControls.isoValues.indexOf(settings.iso),
              onChanged: (i) =>
                  settings.setIso(BottomControls.isoValues[i]),
            ),
          ),
          Expanded(
            child: ManualControlWheel(
              label: 'SHUTTER',
              values: shutterStrings,
              selectedIndex: BottomControls.shutterDenominators
                  .indexOf(settings.shutterSpeedDenominator),
              onChanged: (i) => settings.setShutterSpeed(
                  BottomControls.shutterDenominators[i]),
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterStrip extends StatelessWidget {
  final CameraSettings settings;
  const _FilterStrip({required this.settings});

  @override
  Widget build(BuildContext context) {
    final filters = {
      CinematicFilter.none: 'بدون',
      CinematicFilter.chiaroscuro: 'Chiaroscuro',
      CinematicFilter.warmFilm: 'فيلم دافئ',
      CinematicFilter.coolTeal: 'Teal بارد',
      CinematicFilter.noir: 'Noir',
    };

    return SizedBox(
      height: 34,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: filters.entries.map((entry) {
          final isSelected = settings.activeFilter == entry.key;
          return Padding(
            padding: const EdgeInsets.only(left: 8),
            child: ChoiceChip(
              label: Text(entry.value),
              selected: isSelected,
              onSelected: (_) => settings.setFilter(entry.key),
              selectedColor: AppColors.gold,
              backgroundColor: AppColors.surfaceLight,
              labelStyle: TextStyle(
                color: isSelected ? Colors.black : AppColors.textPrimary,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _ShutterButton extends StatelessWidget {
  final VoidCallback onTap;
  const _ShutterButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 74,
        height: 74,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: AppColors.gold, width: 3),
        ),
        child: Center(
          child: Container(
            width: 58,
            height: 58,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.gold,
            ),
          ),
        ),
      ),
    );
  }
}

class _ManualModeToggle extends StatelessWidget {
  final CameraSettings settings;
  const _ManualModeToggle({required this.settings});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: settings.toggleManualMode,
      child: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: settings.isManualModeEnabled
              ? AppColors.gold
              : AppColors.surfaceLight,
        ),
        child: Icon(
          Icons.tune,
          color: settings.isManualModeEnabled
              ? Colors.black
              : AppColors.textPrimary,
        ),
      ),
    );
  }
}

class _Thumbnail extends StatelessWidget {
  final String? path;
  final bool hasRawFile;
  const _Thumbnail({this.path, this.hasRawFile = false});

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: AppColors.gold, width: 1),
            image: path != null
                ? DecorationImage(
                    image: FileImage(File(path!)),
                    fit: BoxFit.cover,
                  )
                : null,
            color: AppColors.surfaceLight,
          ),
          child: path == null
              ? const Icon(Icons.photo_outlined,
                  color: AppColors.textSecondary, size: 20)
              : null,
        ),
        // شارة صغيرة تُعلم أن ملف RAW (DNG) الأصلي محفوظ أيضاً بجانب
        // JPEG المعروض في المصغّرة - Flutter لا يستطيع فك ترميز DNG
        // نفسه لعرضه كصورة، لذا هذه الشارة هي التأكيد الوحيد للمستخدم.
        if (hasRawFile)
          Positioned(
            bottom: -4,
            right: -4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
              decoration: BoxDecoration(
                color: AppColors.gold,
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Text(
                'RAW',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
      ],
    );
  }
}
