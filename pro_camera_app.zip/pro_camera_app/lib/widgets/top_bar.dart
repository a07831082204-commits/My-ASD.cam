import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/camera_settings.dart';
import '../theme/app_theme.dart';

class TopBar extends StatelessWidget {
  final VoidCallback onToggleVisibility;
  final VoidCallback? onFlashTap;

  const TopBar({
    super.key,
    required this.onToggleVisibility,
    this.onFlashTap,
  });

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<CameraSettings>();

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _RawBadge(
              format: settings.captureFormat,
              onTap: () => _showFormatSheet(context, settings),
            ),
            Row(
              children: [
                _IconButtonGold(
                  icon: Icons.center_focus_strong,
                  isActive: settings.isFocusPeakingEnabled,
                  onTap: settings.toggleFocusPeaking,
                ),
                const SizedBox(width: 8),
                // تم ربطه الآن بالجسر الأصلي عبر setFlashMode (Camera2
                // FLASH_MODE_TORCH على أندرويد، device.torchMode على iOS).
                _IconButtonGold(
                  icon: settings.isFlashOn ? Icons.flash_on : Icons.flash_off,
                  isActive: settings.isFlashOn,
                  onTap: onFlashTap ?? () {},
                ),
                const SizedBox(width: 8),
                _IconButtonGold(
                  icon: Icons.visibility_off_outlined,
                  onTap: onToggleVisibility,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showFormatSheet(BuildContext context, CameraSettings settings) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: CaptureFormat.values.map((f) {
          return ListTile(
            title: Text(_formatLabel(f),
                style: const TextStyle(color: AppColors.textPrimary)),
            trailing: settings.captureFormat == f
                ? const Icon(Icons.check, color: AppColors.gold)
                : null,
            onTap: () {
              settings.setCaptureFormat(f);
              Navigator.pop(context);
            },
          );
        }).toList(),
      ),
    );
  }

  String _formatLabel(CaptureFormat f) {
    switch (f) {
      case CaptureFormat.jpeg:
        return 'JPEG';
      case CaptureFormat.raw:
        return 'RAW';
      case CaptureFormat.rawPlusJpeg:
        return 'RAW + JPEG';
    }
  }
}

class _RawBadge extends StatelessWidget {
  final CaptureFormat format;
  final VoidCallback onTap;
  const _RawBadge({required this.format, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final label = format == CaptureFormat.jpeg
        ? 'JPEG'
        : format == CaptureFormat.raw
            ? 'RAW'
            : 'RAW+JPG';
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.gold, width: 1),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text(
          label,
          style: const TextStyle(
            color: AppColors.gold,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

class _IconButtonGold extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool isActive;
  const _IconButtonGold({
    required this.icon,
    required this.onTap,
    this.isActive = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: isActive ? AppColors.gold : const Color(0x33000000),
          shape: BoxShape.circle,
        ),
        child: Icon(
          icon,
          color: isActive ? Colors.black : AppColors.textPrimary,
          size: 20,
        ),
      ),
    );
  }
}
