import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// عجلة تحكم أفقية شبيهة بعجلات كاميرات DSLR: تمرير بالإصبع
/// لتغيير القيمة، مع خط ذهبي في المنتصف يشير للقيمة الحالية.
///
/// [values] القيم الممكنة (مثال: [50, 100, 200, 400, 800, 1600, 3200])
/// [selectedIndex] الفهرس الحالي المختار
/// [label] عنوان العجلة (مثال: "ISO")
/// [onChanged] يُستدعى بالفهرس الجديد عند تغيّر الاختيار
class ManualControlWheel extends StatefulWidget {
  final List<String> values;
  final int selectedIndex;
  final String label;
  final ValueChanged<int> onChanged;

  const ManualControlWheel({
    super.key,
    required this.values,
    required this.selectedIndex,
    required this.label,
    required this.onChanged,
  });

  @override
  State<ManualControlWheel> createState() => _ManualControlWheelState();
}

class _ManualControlWheelState extends State<ManualControlWheel> {
  static const double _itemWidth = 56;
  late FixedExtentScrollController _scrollController;

  @override
  void initState() {
    super.initState();
    _scrollController = FixedExtentScrollController(
      initialItem: widget.selectedIndex,
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          widget.label,
          style: const TextStyle(
            color: AppColors.gold,
            fontSize: 12,
            fontWeight: FontWeight.w600,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 6),
        SizedBox(
          height: 64,
          width: double.infinity,
          child: Stack(
            alignment: Alignment.center,
            children: [
              ListWheelScrollView.useDelegate(
                controller: _scrollController,
                itemExtent: _itemWidth,
                diameterRatio: 4,
                physics: const FixedExtentScrollPhysics(),
                onSelectedItemChanged: widget.onChanged,
                childDelegate: ListWheelChildBuilderDelegate(
                  childCount: widget.values.length,
                  builder: (context, index) {
                    final isSelected = index == widget.selectedIndex;
                    return Center(
                      child: Text(
                        widget.values[index],
                        style: TextStyle(
                          color: isSelected
                              ? AppColors.goldBright
                              : AppColors.textSecondary,
                          fontSize: isSelected ? 20 : 15,
                          fontWeight:
                              isSelected ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    );
                  },
                ),
              ),
              // مؤشر القيمة الحالية في المنتصف
              IgnorePointer(
                child: Container(
                  width: 2,
                  height: 34,
                  color: AppColors.gold,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
