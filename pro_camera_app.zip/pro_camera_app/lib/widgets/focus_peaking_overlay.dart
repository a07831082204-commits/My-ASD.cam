import 'dart:async';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../services/native_camera_bridge.dart';

/// طبقة شفافة فوق معاينة الكاميرا تُبرز الحواف الحادة (المناطق
/// المركّزة فعلياً) بلون أخضر نابض، عبر استقبال أقنعة حواف جاهزة
/// من الكود الأصلي (Camera2 على أندرويد، AVFoundation على iOS)
/// مباشرة عبر EventChannel - وليس عبر معالجة Dart للفيديو الخام،
/// لأن ذلك كان سيُجمّد الواجهة كما هو موضّح في النسخة السابقة.
///
/// تدفق العمل:
/// 1. عند التفعيل: نطلب من الكود الأصلي بدء بث التحليل
///    (setFocusPeakingEnabled(true))، ثم نستمع لتيار الإطارات.
/// 2. كل إطار (Map يحوي width/height/bytes RGBA) يُحوَّل إلى
///    ui.Image عبر decodeImageFromPixels، وهي عملية غير متزامنة
///    خفيفة لأن الأبعاد صغيرة (~320px).
/// 3. الرسم يتم بتكبير هذه الصورة الصغيرة لتغطي حجم المعاينة
///    الكامل عبر CustomPainter.drawImageRect - وهذا التمديد
///    (upscaling) مقصود ومقبول بصرياً لأن الهدف إظهار "مناطق"
///    التركيز لا تفاصيل دقيقة بكسل بكسل.
class FocusPeakingOverlay extends StatefulWidget {
  final NativeCameraBridge bridge;
  final bool isEnabled;

  const FocusPeakingOverlay({
    super.key,
    required this.bridge,
    required this.isEnabled,
  });

  @override
  State<FocusPeakingOverlay> createState() => _FocusPeakingOverlayState();
}

class _FocusPeakingOverlayState extends State<FocusPeakingOverlay> {
  StreamSubscription<FocusPeakingFrame>? _subscription;
  ui.Image? _currentMask;
  bool _isDecoding = false;

  @override
  void initState() {
    super.initState();
    if (widget.isEnabled) _start();
  }

  @override
  void didUpdateWidget(covariant FocusPeakingOverlay oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isEnabled == oldWidget.isEnabled) return;
    if (widget.isEnabled) {
      _start();
    } else {
      _stop();
    }
  }

  Future<void> _start() async {
    await widget.bridge.setFocusPeakingEnabled(true);
    _subscription = widget.bridge.focusPeakingFrames.listen(_onFrame);
  }

  Future<void> _stop() async {
    await _subscription?.cancel();
    _subscription = null;
    await widget.bridge.setFocusPeakingEnabled(false);
    if (mounted) setState(() => _currentMask = null);
  }

  /// نتجاهل أي إطار جديد يصل أثناء فك ترميز إطار سابق، بدل تكديسها،
  /// حتى لا تتراكم عمليات فك الترميز أسرع مما يمكن عرضه فعلياً.
  Future<void> _onFrame(FocusPeakingFrame frame) async {
    if (_isDecoding) return;
    _isDecoding = true;
    try {
      final completer = Completer<ui.Image>();
      ui.decodeImageFromPixels(
        frame.rgbaBytes,
        frame.width,
        frame.height,
        ui.PixelFormat.rgba8888,
        completer.complete,
      );
      final image = await completer.future;
      if (mounted) setState(() => _currentMask = image);
    } finally {
      _isDecoding = false;
    }
  }

  @override
  void dispose() {
    if (widget.isEnabled) _stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isEnabled || _currentMask == null) {
      return const SizedBox.shrink();
    }
    return IgnorePointer(
      child: CustomPaint(
        painter: _PeakingMaskPainter(_currentMask!),
        child: Container(),
      ),
    );
  }
}

class _PeakingMaskPainter extends CustomPainter {
  final ui.Image mask;
  _PeakingMaskPainter(this.mask);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..filterQuality = FilterQuality.low;
    canvas.drawImageRect(
      mask,
      Rect.fromLTWH(0, 0, mask.width.toDouble(), mask.height.toDouble()),
      Rect.fromLTWH(0, 0, size.width, size.height),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _PeakingMaskPainter oldDelegate) =>
      oldDelegate.mask != mask;
}
