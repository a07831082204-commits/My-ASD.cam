import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'models/camera_settings.dart';
import 'screens/camera_screen.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _requestPermissions();
  runApp(const ProCameraApp());
}

Future<void> _requestPermissions() async {
  // إذن الكاميرا فقط هنا عند الإقلاع، لأن التطبيق لا يعمل إطلاقاً
  // بدونه. لا نطلب المايكروفون لأن الجلسة لا تضيف أي مدخل صوتي
  // (enableAudio لم يُستخدم أصلاً في الجسر الأصلي - تصوير ثابت فقط).
  //
  // إذن المعرض (تخزين/صور) لم يعد يُطلب هنا مسبقاً وبشكل عام؛ أصبحت
  // GalleryService (lib/services/gallery_service.dart) تطلبه بدقة
  // عبر Gal.requestAccess(toAlbum: true) فقط عند أول محاولة حفظ فعلية
  // - وهذا إذن "إضافة فقط" أدق وأقل تطفلاً من طلب "قراءة كل الصور"
  // العام الذي كان يُطلب هنا سابقاً دون داعٍ حقيقي.
  await Permission.camera.request();
}

class ProCameraApp extends StatelessWidget {
  const ProCameraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => CameraSettings()),
      ],
      child: MaterialApp(
        title: 'Pro Camera',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark,
        home: const CameraScreen(),
      ),
    );
  }
}
