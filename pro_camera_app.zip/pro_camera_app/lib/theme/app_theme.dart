import 'package:flutter/material.dart';

/// ثيم موحّد للتطبيق بالكامل: أسود + ذهبي.
/// أي لون يُستخدم في أي واجهة يجب أن يُسحب من هنا فقط،
/// حتى يسهل تغيير هوية التطبيق البصرية من مكان واحد مستقبلاً.
class AppColors {
  static const Color background = Color(0xFF0A0A0A);
  static const Color surface = Color(0xFF161616);
  static const Color surfaceLight = Color(0xFF232323);
  static const Color gold = Color(0xFFD4AF37);
  static const Color goldBright = Color(0xFFF4E5B2);
  static const Color textPrimary = Color(0xFFF5F5F5);
  static const Color textSecondary = Color(0xFF9A9A9A);
  static const Color focusGreen = Color(0xFF34FF6A); // لون Focus Peaking
  static const Color danger = Color(0xFFFF4C4C);
}

class AppTheme {
  static ThemeData get dark {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.background,
      primaryColor: AppColors.gold,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.gold,
        secondary: AppColors.goldBright,
        surface: AppColors.surface,
      ),
      fontFamily: 'Roboto',
      textTheme: const TextTheme(
        bodyMedium: TextStyle(color: AppColors.textPrimary),
        labelSmall: TextStyle(color: AppColors.textSecondary, fontSize: 11),
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: AppColors.gold,
        inactiveTrackColor: AppColors.surfaceLight,
        thumbColor: AppColors.goldBright,
        overlayColor: AppColors.gold.withOpacity(0.2),
      ),
      iconTheme: const IconThemeData(color: AppColors.textPrimary),
      useMaterial3: true,
    );
  }
}
