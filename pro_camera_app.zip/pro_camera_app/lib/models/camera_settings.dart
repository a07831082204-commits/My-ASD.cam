import 'package:flutter/foundation.dart';

enum CaptureFormat { jpeg, raw, rawPlusJpeg }

enum WhiteBalancePreset { auto, daylight, cloudy, tungsten, fluorescent }

enum CinematicFilter { none, chiaroscuro, warmFilm, coolTeal, noir }

/// يمثل هذا الكلاس "مصدر الحقيقة الواحد" لكل إعدادات التصوير اليدوي.
/// كل الودجت (العجلات، الأزرار) تقرأ/تكتب من هنا عبر Provider،
/// وشاشة الكاميرا تستمع لأي تغيير لتطبيقه فعلياً على CameraController.
class CameraSettings extends ChangeNotifier {
  // مدى ISO المعتاد لمعظم أجهزة الجوال: 50 - 3200
  int iso = 100;

  // سرعة الغالق بالثانية (1/x). القيمة المخزنة هي المقام x.
  int shutterSpeedDenominator = 125;

  // تعويض التعريض بالـ EV، عادة من -3 إلى +3
  double exposureCompensation = 0.0;

  // قيمة التركيز اليدوي: 0.0 (أقرب نقطة) إلى 1.0 (اللانهاية)
  double manualFocus = 0.5;
  bool isManualFocusEnabled = false;
  bool isFocusPeakingEnabled = false;

  WhiteBalancePreset whiteBalance = WhiteBalancePreset.auto;
  CaptureFormat captureFormat = CaptureFormat.jpeg;
  CinematicFilter activeFilter = CinematicFilter.none;

  bool isManualModeEnabled = false;
  bool isNoiseReductionEnabled = true;
  bool isFlashOn = false;

  void setIso(int value) {
    iso = value.clamp(50, 3200);
    notifyListeners();
  }

  void setShutterSpeed(int denominator) {
    shutterSpeedDenominator = denominator.clamp(1, 8000);
    notifyListeners();
  }

  void setExposureCompensation(double value) {
    exposureCompensation = value.clamp(-3.0, 3.0);
    notifyListeners();
  }

  void setManualFocus(double value) {
    manualFocus = value.clamp(0.0, 1.0);
    notifyListeners();
  }

  void toggleManualFocus() {
    isManualFocusEnabled = !isManualFocusEnabled;
    notifyListeners();
  }

  void toggleFocusPeaking() {
    isFocusPeakingEnabled = !isFocusPeakingEnabled;
    notifyListeners();
  }

  void setWhiteBalance(WhiteBalancePreset preset) {
    whiteBalance = preset;
    notifyListeners();
  }

  void setCaptureFormat(CaptureFormat format) {
    captureFormat = format;
    notifyListeners();
  }

  void setFilter(CinematicFilter filter) {
    activeFilter = filter;
    notifyListeners();
  }

  void toggleManualMode() {
    isManualModeEnabled = !isManualModeEnabled;
    notifyListeners();
  }

  void toggleNoiseReduction() {
    isNoiseReductionEnabled = !isNoiseReductionEnabled;
    notifyListeners();
  }

  void toggleFlash() {
    isFlashOn = !isFlashOn;
    notifyListeners();
  }
}
