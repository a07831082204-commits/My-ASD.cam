import 'dart:typed_data';

/// خريطة عمق مُطبَّعة بالكامل إلى المدى [0.0, 1.0]، حيث:
/// - 1.0 يعني "أقرب نقطة للكاميرا" (عادة الموضوع الرئيسي في الصورة)
/// - 0.0 يعني "أبعد نقطة" (الخلفية)
///
/// هذا هو اتفاق MiDaS القياسي: الشبكة تُخرج "عمقاً عكسياً نسبياً"
/// (inverse relative depth) وليس مسافة حقيقية بالمتر، لذلك القيم هنا
/// مفيدة فقط للمقارنة النسبية بين بكسلات نفس الصورة، وليست قابلة
/// للمقارنة بين صور مختلفة أو كمقياس مسافة فعلي.
class DepthMap {
  final int width;
  final int height;
  final Float32List values;

  DepthMap({
    required this.width,
    required this.height,
    required this.values,
  }) : assert(values.length == width * height);

  double at(int x, int y) => values[y * width + x];
}
